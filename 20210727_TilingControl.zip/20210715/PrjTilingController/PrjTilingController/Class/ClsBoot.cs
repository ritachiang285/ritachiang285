﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrjTilingController.Class
{

    public delegate bool funcSendCoarseMsgToDACallBack(string o_ToDaMsg, int o_Position,
        string o_FrameId, string o_GlassPanelId,
        ref double o_X, ref double o_Y, ref double o_Theta);

    public delegate bool funcSendFineMsgToDACallBack(string o_ToDaMsg, int o_Position,
        string o_FrameId, string o_GlassPanelId,
        ref double o_X, ref double o_Y, ref double o_Theta);

    public delegate void funcChangeCurrentStatusCallBack(string o_Status);


    public static class Common
    {
        public static string TILING_NAME = "Tiling_Controller";
        public static string TILING_VERSION = "V001";
        public static string TILING_REVERSION = "21.0617.1929";
        public static string TILING_CONTROLLER_APP_VERSION = 
            (TILING_NAME + "_" + TILING_VERSION + "_" + TILING_REVERSION);

        public static string CONFIG_FOLDER = System.Windows.Forms.Application.StartupPath + "\\CtrlConfig\\";
        public static string DEFAULT_CONFIG_FOLDER = System.Windows.Forms.Application.StartupPath + "\\DefaultCtrlConfig\\";

        public static string BOOT_CONFIG_NAME = "BootConfig.xml";
        public static string NETWORK_CONFIG_NAME = "NetworkConfig.xml";
        public static string PLC_CONFIG_NAME = "PlcConfig.xml";
        public static string RECORD_CONFIG_NAME = "RecordConfig.xml";

        public static string RECORD_RESULT_NAME = "RecordResult.xml";
    }

    public partial class ClsBootConfig : CommonBase.Config.BaseConfig<ClsBootConfig>
    {
        private string classVersion = "ClsBootConfig_202103191115";

        public string rootPath;

        public ClsBootConfig()
        {
            this.rootPath = "D:\\Tiling";
        }
        protected override bool CheckValue(ClsBootConfig tmpConfig)
        {
            this.rootPath = tmpConfig.rootPath;

            //	Read UPDATE
            this.Update = tmpConfig.Update;

            //	Read VERSION
            this.Version = this.classVersion;

            if (this.Version != tmpConfig.Version)
                return false;
            else
                return true;
        }

    }
}
