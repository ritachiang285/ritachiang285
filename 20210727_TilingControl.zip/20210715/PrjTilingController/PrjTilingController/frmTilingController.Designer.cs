﻿
namespace PrjTilingController
{
    partial class frmTilingController
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTilingController));
            this.btnStartDetect = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tpLogSystem = new System.Windows.Forms.TabPage();
            this.rtfLogSystem = new System.Windows.Forms.RichTextBox();
            this.tpLogNet = new System.Windows.Forms.TabPage();
            this.rtfLogNet = new System.Windows.Forms.RichTextBox();
            this.tpLogWarning = new System.Windows.Forms.TabPage();
            this.rtfLogWarning = new System.Windows.Forms.RichTextBox();
            this.tpLogError = new System.Windows.Forms.TabPage();
            this.rtfLogError = new System.Windows.Forms.RichTextBox();
            this.tpLogDebug = new System.Windows.Forms.TabPage();
            this.rtfLogDebug = new System.Windows.Forms.RichTextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.tsmiConfig = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiPlcConfig = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiNetworkConfig = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.btnResetToInitial = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnSendMsgToDaTest = new System.Windows.Forms.Button();
            this.btnHideLog = new System.Windows.Forms.Button();
            this.tmrAlive = new System.Windows.Forms.Timer(this.components);
            this.pnlAliveCheck = new System.Windows.Forms.Panel();
            this.dtpNowDate = new System.Windows.Forms.DateTimePicker();
            this.lblCurrentStatus = new System.Windows.Forms.Label();
            this.cboDaCommand = new System.Windows.Forms.ComboBox();
            this.txtDaPosition = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tpLogSystem.SuspendLayout();
            this.tpLogNet.SuspendLayout();
            this.tpLogWarning.SuspendLayout();
            this.tpLogError.SuspendLayout();
            this.tpLogDebug.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnStartDetect
            // 
            this.btnStartDetect.BackColor = System.Drawing.Color.Green;
            this.btnStartDetect.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnStartDetect.Location = new System.Drawing.Point(12, 27);
            this.btnStartDetect.Name = "btnStartDetect";
            this.btnStartDetect.Size = new System.Drawing.Size(96, 68);
            this.btnStartDetect.TabIndex = 0;
            this.btnStartDetect.Text = "Start";
            this.btnStartDetect.UseVisualStyleBackColor = false;
            this.btnStartDetect.Click += new System.EventHandler(this.btnStartDetect_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tpLogSystem);
            this.tabControl1.Controls.Add(this.tpLogNet);
            this.tabControl1.Controls.Add(this.tpLogWarning);
            this.tabControl1.Controls.Add(this.tpLogError);
            this.tabControl1.Controls.Add(this.tpLogDebug);
            this.tabControl1.Location = new System.Drawing.Point(12, 428);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(616, 289);
            this.tabControl1.TabIndex = 1;
            // 
            // tpLogSystem
            // 
            this.tpLogSystem.Controls.Add(this.rtfLogSystem);
            this.tpLogSystem.Location = new System.Drawing.Point(4, 26);
            this.tpLogSystem.Name = "tpLogSystem";
            this.tpLogSystem.Padding = new System.Windows.Forms.Padding(3);
            this.tpLogSystem.Size = new System.Drawing.Size(608, 259);
            this.tpLogSystem.TabIndex = 0;
            this.tpLogSystem.Text = "System";
            this.tpLogSystem.UseVisualStyleBackColor = true;
            // 
            // rtfLogSystem
            // 
            this.rtfLogSystem.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rtfLogSystem.BackColor = System.Drawing.SystemColors.Info;
            this.rtfLogSystem.Location = new System.Drawing.Point(0, 0);
            this.rtfLogSystem.Name = "rtfLogSystem";
            this.rtfLogSystem.Size = new System.Drawing.Size(608, 259);
            this.rtfLogSystem.TabIndex = 2;
            this.rtfLogSystem.Text = "";
            // 
            // tpLogNet
            // 
            this.tpLogNet.Controls.Add(this.rtfLogNet);
            this.tpLogNet.Location = new System.Drawing.Point(4, 26);
            this.tpLogNet.Name = "tpLogNet";
            this.tpLogNet.Padding = new System.Windows.Forms.Padding(3);
            this.tpLogNet.Size = new System.Drawing.Size(608, 259);
            this.tpLogNet.TabIndex = 1;
            this.tpLogNet.Text = "Net";
            this.tpLogNet.UseVisualStyleBackColor = true;
            // 
            // rtfLogNet
            // 
            this.rtfLogNet.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rtfLogNet.BackColor = System.Drawing.SystemColors.Info;
            this.rtfLogNet.Location = new System.Drawing.Point(0, 0);
            this.rtfLogNet.Name = "rtfLogNet";
            this.rtfLogNet.Size = new System.Drawing.Size(491, 483);
            this.rtfLogNet.TabIndex = 3;
            this.rtfLogNet.Text = "";
            // 
            // tpLogWarning
            // 
            this.tpLogWarning.Controls.Add(this.rtfLogWarning);
            this.tpLogWarning.Location = new System.Drawing.Point(4, 26);
            this.tpLogWarning.Name = "tpLogWarning";
            this.tpLogWarning.Size = new System.Drawing.Size(608, 259);
            this.tpLogWarning.TabIndex = 2;
            this.tpLogWarning.Text = "Warning";
            this.tpLogWarning.UseVisualStyleBackColor = true;
            // 
            // rtfLogWarning
            // 
            this.rtfLogWarning.BackColor = System.Drawing.SystemColors.Info;
            this.rtfLogWarning.Location = new System.Drawing.Point(0, 0);
            this.rtfLogWarning.Name = "rtfLogWarning";
            this.rtfLogWarning.Size = new System.Drawing.Size(491, 483);
            this.rtfLogWarning.TabIndex = 4;
            this.rtfLogWarning.Text = "";
            // 
            // tpLogError
            // 
            this.tpLogError.Controls.Add(this.rtfLogError);
            this.tpLogError.Location = new System.Drawing.Point(4, 26);
            this.tpLogError.Name = "tpLogError";
            this.tpLogError.Size = new System.Drawing.Size(608, 259);
            this.tpLogError.TabIndex = 3;
            this.tpLogError.Text = "Error";
            this.tpLogError.UseVisualStyleBackColor = true;
            // 
            // rtfLogError
            // 
            this.rtfLogError.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rtfLogError.BackColor = System.Drawing.SystemColors.Info;
            this.rtfLogError.Location = new System.Drawing.Point(0, 0);
            this.rtfLogError.Name = "rtfLogError";
            this.rtfLogError.Size = new System.Drawing.Size(491, 483);
            this.rtfLogError.TabIndex = 5;
            this.rtfLogError.Text = "";
            // 
            // tpLogDebug
            // 
            this.tpLogDebug.Controls.Add(this.rtfLogDebug);
            this.tpLogDebug.Location = new System.Drawing.Point(4, 26);
            this.tpLogDebug.Name = "tpLogDebug";
            this.tpLogDebug.Size = new System.Drawing.Size(608, 259);
            this.tpLogDebug.TabIndex = 4;
            this.tpLogDebug.Text = "Debug";
            this.tpLogDebug.UseVisualStyleBackColor = true;
            // 
            // rtfLogDebug
            // 
            this.rtfLogDebug.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rtfLogDebug.BackColor = System.Drawing.SystemColors.Info;
            this.rtfLogDebug.Location = new System.Drawing.Point(0, 0);
            this.rtfLogDebug.Name = "rtfLogDebug";
            this.rtfLogDebug.Size = new System.Drawing.Size(491, 483);
            this.rtfLogDebug.TabIndex = 5;
            this.rtfLogDebug.Text = "";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiConfig,
            this.tsmiAbout});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(640, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // tsmiConfig
            // 
            this.tsmiConfig.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiPlcConfig,
            this.tsmiNetworkConfig});
            this.tsmiConfig.Name = "tsmiConfig";
            this.tsmiConfig.Size = new System.Drawing.Size(57, 20);
            this.tsmiConfig.Text = "Config";
            // 
            // tsmiPlcConfig
            // 
            this.tsmiPlcConfig.Name = "tsmiPlcConfig";
            this.tsmiPlcConfig.Size = new System.Drawing.Size(160, 22);
            this.tsmiPlcConfig.Text = "Plc Config";
            this.tsmiPlcConfig.Click += new System.EventHandler(this.tsmiPlcConfig_Click);
            // 
            // tsmiNetworkConfig
            // 
            this.tsmiNetworkConfig.Name = "tsmiNetworkConfig";
            this.tsmiNetworkConfig.Size = new System.Drawing.Size(160, 22);
            this.tsmiNetworkConfig.Text = "NetworkConfig";
            this.tsmiNetworkConfig.Click += new System.EventHandler(this.tsmiNetworkConfig_Click);
            // 
            // tsmiAbout
            // 
            this.tsmiAbout.Name = "tsmiAbout";
            this.tsmiAbout.Size = new System.Drawing.Size(54, 20);
            this.tsmiAbout.Text = "About";
            this.tsmiAbout.Click += new System.EventHandler(this.tsmiAbout_Click);
            // 
            // btnResetToInitial
            // 
            this.btnResetToInitial.BackColor = System.Drawing.Color.LightBlue;
            this.btnResetToInitial.Location = new System.Drawing.Point(114, 63);
            this.btnResetToInitial.Name = "btnResetToInitial";
            this.btnResetToInitial.Size = new System.Drawing.Size(75, 50);
            this.btnResetToInitial.TabIndex = 4;
            this.btnResetToInitial.Text = "Reset To Initial";
            this.btnResetToInitial.UseVisualStyleBackColor = false;
            this.btnResetToInitial.Click += new System.EventHandler(this.btnResetToInitial_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Location = new System.Drawing.Point(12, 131);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.Size = new System.Drawing.Size(612, 261);
            this.dataGridView1.TabIndex = 5;
            // 
            // btnSendMsgToDaTest
            // 
            this.btnSendMsgToDaTest.Location = new System.Drawing.Point(195, 63);
            this.btnSendMsgToDaTest.Name = "btnSendMsgToDaTest";
            this.btnSendMsgToDaTest.Size = new System.Drawing.Size(75, 50);
            this.btnSendMsgToDaTest.TabIndex = 6;
            this.btnSendMsgToDaTest.Text = "Send To DA";
            this.btnSendMsgToDaTest.UseVisualStyleBackColor = true;
            this.btnSendMsgToDaTest.Click += new System.EventHandler(this.btnSendMsgToDaTest_Click);
            // 
            // btnHideLog
            // 
            this.btnHideLog.Location = new System.Drawing.Point(12, 398);
            this.btnHideLog.Name = "btnHideLog";
            this.btnHideLog.Size = new System.Drawing.Size(612, 24);
            this.btnHideLog.TabIndex = 8;
            this.btnHideLog.Text = "^ ^ ^";
            this.btnHideLog.UseVisualStyleBackColor = true;
            this.btnHideLog.Click += new System.EventHandler(this.btnHideLog_Click);
            // 
            // tmrAlive
            // 
            this.tmrAlive.Interval = 1000;
            this.tmrAlive.Tick += new System.EventHandler(this.tmrAlive_Tick);
            // 
            // pnlAliveCheck
            // 
            this.pnlAliveCheck.Location = new System.Drawing.Point(246, 32);
            this.pnlAliveCheck.Name = "pnlAliveCheck";
            this.pnlAliveCheck.Size = new System.Drawing.Size(25, 25);
            this.pnlAliveCheck.TabIndex = 9;
            // 
            // dtpNowDate
            // 
            this.dtpNowDate.Location = new System.Drawing.Point(114, 32);
            this.dtpNowDate.Name = "dtpNowDate";
            this.dtpNowDate.Size = new System.Drawing.Size(126, 25);
            this.dtpNowDate.TabIndex = 10;
            // 
            // lblCurrentStatus
            // 
            this.lblCurrentStatus.AutoSize = true;
            this.lblCurrentStatus.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblCurrentStatus.ForeColor = System.Drawing.Color.Tomato;
            this.lblCurrentStatus.Location = new System.Drawing.Point(277, 35);
            this.lblCurrentStatus.Name = "lblCurrentStatus";
            this.lblCurrentStatus.Size = new System.Drawing.Size(176, 20);
            this.lblCurrentStatus.TabIndex = 11;
            this.lblCurrentStatus.Text = "[Fine] Set Measure NG";
            // 
            // cboDaCommand
            // 
            this.cboDaCommand.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDaCommand.FormattingEnabled = true;
            this.cboDaCommand.Location = new System.Drawing.Point(276, 63);
            this.cboDaCommand.Name = "cboDaCommand";
            this.cboDaCommand.Size = new System.Drawing.Size(121, 25);
            this.cboDaCommand.TabIndex = 12;
            // 
            // txtDaPosition
            // 
            this.txtDaPosition.Location = new System.Drawing.Point(276, 94);
            this.txtDaPosition.Name = "txtDaPosition";
            this.txtDaPosition.Size = new System.Drawing.Size(121, 25);
            this.txtDaPosition.TabIndex = 13;
            this.txtDaPosition.Text = "1";
            // 
            // frmTilingController
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(640, 725);
            this.Controls.Add(this.txtDaPosition);
            this.Controls.Add(this.cboDaCommand);
            this.Controls.Add(this.lblCurrentStatus);
            this.Controls.Add(this.dtpNowDate);
            this.Controls.Add(this.pnlAliveCheck);
            this.Controls.Add(this.btnHideLog);
            this.Controls.Add(this.btnSendMsgToDaTest);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnResetToInitial);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btnStartDetect);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "frmTilingController";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmTilingController";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmTilingController_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmTilingController_FormClosed);
            this.Load += new System.EventHandler(this.frmTilingController_Load);
            this.tabControl1.ResumeLayout(false);
            this.tpLogSystem.ResumeLayout(false);
            this.tpLogNet.ResumeLayout(false);
            this.tpLogWarning.ResumeLayout(false);
            this.tpLogError.ResumeLayout(false);
            this.tpLogDebug.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnStartDetect;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tpLogSystem;
        private System.Windows.Forms.TabPage tpLogNet;
        private System.Windows.Forms.TabPage tpLogWarning;
        private System.Windows.Forms.TabPage tpLogError;
        private System.Windows.Forms.TabPage tpLogDebug;
        private System.Windows.Forms.RichTextBox rtfLogSystem;
        private System.Windows.Forms.RichTextBox rtfLogNet;
        private System.Windows.Forms.RichTextBox rtfLogWarning;
        private System.Windows.Forms.RichTextBox rtfLogError;
        private System.Windows.Forms.RichTextBox rtfLogDebug;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tsmiConfig;
        private System.Windows.Forms.ToolStripMenuItem tsmiAbout;
        private System.Windows.Forms.ToolStripMenuItem tsmiPlcConfig;
        private System.Windows.Forms.ToolStripMenuItem tsmiNetworkConfig;
        private System.Windows.Forms.Button btnResetToInitial;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnSendMsgToDaTest;
        private System.Windows.Forms.Button btnHideLog;
        private System.Windows.Forms.Timer tmrAlive;
        private System.Windows.Forms.Panel pnlAliveCheck;
        private System.Windows.Forms.DateTimePicker dtpNowDate;
        private System.Windows.Forms.Label lblCurrentStatus;
        private System.Windows.Forms.ComboBox cboDaCommand;
        private System.Windows.Forms.TextBox txtDaPosition;
    }
}

