﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PrjTilingController.Class;
using System.Threading;
using System.Resources;


namespace PrjTilingController
{
    public partial class frmTilingController : Form
    {

        // Start app DateTime
        DateTime g_StartApplicationDay;

        // Log
        private CommonBase.Logger.InfoManager g_InfoManager;

        // Config
        private ClsBootConfig g_ClsBootConfig = null;
        private ClsPlcConfig g_ClsPlcConfig = null;
        private ClsNetworkConfig g_ClsNetworkConfig = null;
        private ClsRecordConfig g_ClsRecordConfig = null;

        // Control
        private ClsPlcControl g_ClsPlcControl = null;
        private ClsNetworkControl g_ClsNetworkControl = null;
        private ClsRecordControl g_ClsRecordControl = null;
        private BindingSource g_BindingSource = null;

        // Form
        private frmPlcConfig g_frmPlcConfig = null;
        private frmNetworkConfig g_frmNetworkConfig = null;
        private frmAbout g_frmAbout = null;

        // Alive
        private bool g_toggle = false;

        // Update UI
        private bool g_UpdateRecordInfo = false;


        public frmTilingController()
        {
            InitializeComponent();
        }

        // func
        private void funcCheckConfigExists()
        {

            // Network config
            if (!File.Exists(Common.CONFIG_FOLDER + Common.NETWORK_CONFIG_NAME))
            {
                ClsNetworkConfig temp_ClsNetworkConfig = new ClsNetworkConfig();
                temp_ClsNetworkConfig.WriteWithoutCrypto(Common.CONFIG_FOLDER + Common.NETWORK_CONFIG_NAME, true);
                this.g_InfoManager.HighLight("Network config is not exist, new one : " + Common.CONFIG_FOLDER + Common.NETWORK_CONFIG_NAME);
            }

            // Plc config
            if (!File.Exists(Common.CONFIG_FOLDER + Common.PLC_CONFIG_NAME))
            {
                ClsPlcConfig temp_ClsPlcConfig = new ClsPlcConfig();
                temp_ClsPlcConfig.WriteWithoutCrypto(Common.CONFIG_FOLDER + Common.PLC_CONFIG_NAME, true);
                this.g_InfoManager.HighLight("Plc config is not exist, new one : " + Common.CONFIG_FOLDER + Common.PLC_CONFIG_NAME);
            }

            // Record config
            if (!File.Exists(Common.CONFIG_FOLDER + Common.RECORD_CONFIG_NAME))
            {
                ClsRecordConfig temp_ClsRecordConfig = new ClsRecordConfig();
                temp_ClsRecordConfig.WriteWithoutCrypto(Common.CONFIG_FOLDER + Common.RECORD_CONFIG_NAME, true);
                this.g_InfoManager.HighLight("Record config is not exist, new one : " + Common.CONFIG_FOLDER + Common.RECORD_CONFIG_NAME);
            }

        }

        private bool funcSendCoarseMsgToDA(string o_ToDaMsg, int o_Position, ref double o_X, ref double o_Y, ref double o_Theta)
        {
            bool ret = true;

            try
            {
                CommonBase.Network.Request request = new CommonBase.Network.Request();
                CommonBase.Network.Response temp_Response = null;

                request.Command = o_ToDaMsg;
                request.Param1 = o_Position.ToString();
                request.Param2 = "";
                request.Param3 = "";
                request.Param4 = "";
                request.Param5 = "";
                request.Param6 = "";
                request.Param7 = "";
                request.Param8 = "";
                request.Param9 = "";

                this.g_ClsNetworkControl.SendMessage(request, ref temp_Response);

                if (temp_Response == null)
                {
                    ret = false;
                }
                else
                {
                    _stRecordMsg_ temp_stRecordMsg_ = null;

                    if (temp_Response.Result == CommonBase.Network.ResponseResult.OK)
                    {
                        bool isConvert = true;
                        if (!Double.TryParse(temp_Response.Param1, out o_X))
                        {
                            isConvert = false;
                        }

                        if (!Double.TryParse(temp_Response.Param2, out o_Y))
                        {
                            isConvert = false;
                        }

                        if (Double.TryParse(temp_Response.Param3, out o_Theta))
                        {
                            isConvert = false;
                        }

                        this.g_InfoManager.HighLight("[Coarse] Receive COARSE OK!");
                        if (isConvert)
                        {
                            this.g_InfoManager.HighLight(string.Format("[Coarse] Receive DA Msg - X:{0}, Y:{1}, Theta:{2}", o_X, o_Y, o_Theta));
                        }
                    }
                    else if (temp_Response.Result == CommonBase.Network.ResponseResult.ERR)
                    {
                        this.g_InfoManager.Error("[Coarse] DA response an err msg : " + temp_Response.Param1);
                        ret = false;
                    }
                    else if (temp_Response.Result == CommonBase.Network.ResponseResult.TIMEOUT)
                    {
                        this.g_InfoManager.Error("[Coarse] Receive DA msg TimeOut");
                        ret = false;
                    }

                    temp_stRecordMsg_ = new _stRecordMsg_
                    (this.g_ClsRecordControl.m_stRecordMsg_.Count(),
                    DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"), request.Command + " : " + o_Position, temp_Response.Result.ToString(),
                    o_X.ToString("F3"), o_Y.ToString("F3"), o_Theta.ToString("F3"));

                    this.g_ClsRecordControl.RecordAddOneResult(temp_stRecordMsg_, this.g_StartApplicationDay.ToString("yyyyMMdd"));
                    this.g_UpdateRecordInfo = true;

                    try
                    {
                        string tempSaveRecordFilePath = this.g_ClsRecordConfig.recordPath + "\\" + this.g_StartApplicationDay.ToString("yyyyMMdd") + "_" + Common.RECORD_RESULT_NAME;
                        ClsRecordControl.WriteXML(this.g_ClsRecordControl, tempSaveRecordFilePath);
                    }
                    catch (Exception ex)
                    {
                        this.g_InfoManager.Error(ex.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
                ret = false;
            }

            return ret;
        }

        private bool funcSendFineMsgToDA(string o_ToDaMsg, int o_Position, ref double o_X, ref double o_Y, ref double o_Theta)
        {
            bool ret = true;

            try
            {
                CommonBase.Network.Request request = new CommonBase.Network.Request();
                CommonBase.Network.Response temp_Response = null;

                request.Command = o_ToDaMsg;
                request.Param1 = o_Position.ToString();
                request.Param2 = "";
                request.Param3 = "";
                request.Param4 = "";
                request.Param5 = "";
                request.Param6 = "";
                request.Param7 = "";
                request.Param8 = "";
                request.Param9 = "";

                this.g_ClsNetworkControl.SendMessage(request, ref temp_Response);

                if (temp_Response == null)
                {
                    ret = false;
                }
                else
                {
                    _stRecordMsg_ temp_stRecordMsg_ = null;

                    if (temp_Response.Result == CommonBase.Network.ResponseResult.OK)
                    {
                        bool isConvert = true;
                        if (!Double.TryParse(temp_Response.Param1, out o_X))
                        {
                            isConvert = false;
                        }

                        if (!Double.TryParse(temp_Response.Param2, out o_Y))
                        {
                            isConvert = false;
                        }

                        if (Double.TryParse(temp_Response.Param3, out o_Theta))
                        {
                            isConvert = false;
                        }

                        this.g_InfoManager.HighLight("[Fine] Receive FINE OK!");
                        if (isConvert)
                        {
                            this.g_InfoManager.HighLight(string.Format("[Fine] Receive DA Msg - X:{0}, Y:{1}, Theta:{2}", o_X, o_Y, o_Theta));
                        }
                    }
                    else if (temp_Response.Result == CommonBase.Network.ResponseResult.ERR)
                    {
                        this.g_InfoManager.Error("[Fine] DA response an err msg : " + temp_Response.Param1);
                        ret = false;
                    }
                    else if (temp_Response.Result == CommonBase.Network.ResponseResult.TIMEOUT)
                    {
                        this.g_InfoManager.Error("[Fine] Receive DA msg TimeOut");
                        ret = false;
                    }

                    temp_stRecordMsg_ = new _stRecordMsg_
                    (this.g_ClsRecordControl.m_stRecordMsg_.Count(),
                    DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"), request.Command + " : " + o_Position, temp_Response.Result.ToString(),
                    o_X.ToString("F3"), o_Y.ToString("F3"), o_Theta.ToString("F3"));

                    this.g_ClsRecordControl.RecordAddOneResult(temp_stRecordMsg_, this.g_StartApplicationDay.ToString("yyyyMMdd"));
                    this.g_UpdateRecordInfo = true;

                    try
                    {
                        string tempSaveRecordFilePath = this.g_ClsRecordConfig.recordPath + "\\" + this.g_StartApplicationDay.ToString("yyyyMMdd") + "_" + Common.RECORD_RESULT_NAME;
                        ClsRecordControl.WriteXML(this.g_ClsRecordControl, tempSaveRecordFilePath);
                    }
                    catch (Exception ex)
                    {
                        this.g_InfoManager.Error(ex.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
                ret = false;
            }

            return ret;
        }

        private void funcChangeCurrentStatus(string o_Status)
        {
            try
            {
                if (this.lblCurrentStatus.InvokeRequired)
                {
                    Invoke(new funcChangeCurrentStatusCallBack(funcChangeCurrentStatus), new Object[] { o_Status });
                }
                else
                {
                    this.lblCurrentStatus.Text = o_Status;
                }
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }
        }

        private bool funcStartDetect()
        {
            // 0. Plc Setting
            try
            {
                this.g_ClsPlcConfig = new ClsPlcConfig();
                if (File.Exists(Common.CONFIG_FOLDER + Common.PLC_CONFIG_NAME))
                {
                    this.g_ClsPlcConfig.ReadWithoutCrypto(Common.CONFIG_FOLDER + Common.PLC_CONFIG_NAME);
                }
                //
                this.g_frmPlcConfig.UpdateObject(this.g_ClsPlcConfig);

                this.g_ClsPlcControl = new ClsPlcControl(this.g_ClsPlcConfig, this.g_InfoManager);

                this.g_ClsPlcControl.funcSendCoarseMsgToDA += new funcSendCoarseMsgToDACallBack(this.funcSendCoarseMsgToDA);
                this.g_ClsPlcControl.funcSendFineMsgToDA += new funcSendFineMsgToDACallBack(this.funcSendFineMsgToDA);
                this.g_ClsPlcControl.funcChangeCurrentStatus += new funcChangeCurrentStatusCallBack(this.funcChangeCurrentStatus);

                if (!this.g_ClsPlcControl.Initial())
                {
                    this.g_InfoManager.Error("----- Initial Plc Fail");
                    return false;
                }
                else
                {
                    this.g_ClsPlcControl.StartDetect();
                    this.g_InfoManager.HighLight("---- Initial Plc OK");
                }


            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error("----- Initial Plc Fail. " + ex.Message);
                return false;
            }

            // 1. Network Setting
            try
            {
                this.g_ClsNetworkConfig = new ClsNetworkConfig();
                if (File.Exists(Common.CONFIG_FOLDER + Common.NETWORK_CONFIG_NAME))
                {
                    this.g_ClsNetworkConfig.ReadWithoutCrypto(Common.CONFIG_FOLDER + Common.NETWORK_CONFIG_NAME);
                }
                this.g_frmNetworkConfig.UpdateObject(this.g_ClsNetworkConfig);

                this.g_ClsNetworkControl = new ClsNetworkControl(this.g_ClsNetworkConfig, this.g_InfoManager);

                this.g_ClsNetworkControl.StratConnect();

            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error("----- Initial Network Fail. " + ex.Message);
                return false;
            }
           
            // 2. Record Setting
            try
            {
                this.g_ClsRecordConfig = new ClsRecordConfig();
                if (File.Exists(Common.CONFIG_FOLDER + Common.RECORD_CONFIG_NAME))
                {
                    this.g_ClsRecordConfig.ReadWithoutCrypto(Common.CONFIG_FOLDER + Common.RECORD_CONFIG_NAME);
                }
                //this.g_frmNetworkConfig.UpdateObject(this.g_ClsNetworkConfig);

                this.g_ClsRecordControl = new ClsRecordControl(this.g_ClsRecordConfig, this.g_StartApplicationDay.ToString(), this.g_InfoManager);

                //
                string tempRecordFilePaht = this.g_ClsRecordConfig.recordPath + "\\" + this.g_StartApplicationDay.ToString("yyyyMMdd") + "_" + Common.RECORD_RESULT_NAME;
                if (System.IO.File.Exists(tempRecordFilePaht))
                {
                    this.g_ClsRecordControl = ClsRecordControl.ReadXML(tempRecordFilePaht);
                }

                //
                if (this.g_BindingSource != null)
                {
                    this.g_BindingSource.Dispose();
                    this.g_BindingSource = null;
                }
                this.g_BindingSource = new BindingSource();

                this.g_BindingSource.DataSource = this.g_ClsRecordControl.m_stRecordMsg_;

                this.dataGridView1.DataSource = this.g_BindingSource;

            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error("----- Initial Record Fail. " + ex.Message);
                return false;
            }
            

            return true;
        }

        private bool funcStopDetect()
        {
            // 0. Plc Setting
            try
            {
                if (this.g_ClsPlcControl != null)
                {
                    this.g_ClsPlcControl.StopDetect();
                }
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error("----- Close Plc Fail " + ex.Message);
            }

            // 1. Network Setting
            try
            {
                if (this.g_ClsNetworkControl != null)
                {
                    this.g_ClsNetworkControl.StopConnect();
                }
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error("----- Close Network Fail " + ex.Message);
            }

            return true;
        }

        private void btnStartDetect_Click(object sender, EventArgs e)
        {

            if (this.btnStartDetect.Text == "Start")
		    {
                if (this.funcStartDetect()) 
                {
                    this.g_StartApplicationDay = DateTime.Today;
                    this.g_InfoManager.HighLight("---- Start Detect ----");
                    this.g_InfoManager.HighLight("Start Day : " + this.g_StartApplicationDay.ToString("yyyyMMdd"));

                    this.btnStartDetect.Text = "Stop";
                    this.btnStartDetect.BackColor = Color.Red;
                    this.tmrAlive.Enabled = true;

                    this.lblCurrentStatus.Text = "Waiting msg";
                }
            }
            else
            {
                // Display a MsgBox asking the user to save changes or abort.
                if (MessageBox.Show("是否停止檢測?\r\nStop detecting?", Common.TILING_NAME, MessageBoxButtons.YesNo)
                    == System.Windows.Forms.DialogResult.Yes)
                {
                }
                else
                {
                    return;
                }

                if (this.funcStopDetect())
                {
                    this.g_StartApplicationDay = DateTime.Today;
                    this.g_InfoManager.HighLight("---- Stop Detect ----");
                    this.g_InfoManager.HighLight("Stop Day : " + this.g_StartApplicationDay.ToString("yyyyMMdd"));

                    this.btnStartDetect.Text = "Start";
                    this.btnStartDetect.BackColor = Color.Green;
                    this.tmrAlive.Enabled = false;

                    this.lblCurrentStatus.Text = "Stand by";

                }
            }
        }

        private void frmTilingController_Load(object sender, EventArgs e)
        {
            // Version
            this.Text = Common.TILING_CONTROLLER_APP_VERSION;

            //
            this.lblCurrentStatus.Text = "Stand by";

            //
            this.cboDaCommand.DataSource = Enum.GetValues(typeof(EnumDaCommand));

            // boot config
            this.g_ClsBootConfig = new ClsBootConfig();
            if (File.Exists(Common.CONFIG_FOLDER + Common.BOOT_CONFIG_NAME))
            {
                try
                {
                    this.g_ClsBootConfig.ReadWithoutCrypto(Common.CONFIG_FOLDER + Common.BOOT_CONFIG_NAME);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                    this.g_ClsBootConfig.ReadWithoutCrypto(Common.DEFAULT_CONFIG_FOLDER + Common.BOOT_CONFIG_NAME);
                }
                this.g_ClsBootConfig.WriteWithoutCrypto(Common.CONFIG_FOLDER + Common.BOOT_CONFIG_NAME, true);
            }
            else
            {
                try
                {
                    string temp_BootConfigFolder = Path.GetDirectoryName(Common.CONFIG_FOLDER + Common.BOOT_CONFIG_NAME);
                    if (!Directory.Exists(temp_BootConfigFolder))
                    {
                        Directory.CreateDirectory(temp_BootConfigFolder);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString(), "Create BootConfig folder fail");
                }

                this.g_ClsBootConfig.WriteWithoutCrypto(Common.CONFIG_FOLDER + Common.BOOT_CONFIG_NAME, true);
            }

            // log 
            // controller
            try
            {
                this.g_InfoManager = new CommonBase.Logger.InfoManager(
                    this.g_ClsBootConfig.rootPath + "\\Log\\systemlog",
                    this.g_ClsBootConfig.rootPath + "\\Log\\networklog",
                    this.g_ClsBootConfig.rootPath + "\\Log\\warninglog",
                    this.g_ClsBootConfig.rootPath + "\\Log\\errorlog",
                    this.g_ClsBootConfig.rootPath + "\\Log\\debuglog");

                this.g_InfoManager.SetGeneralTextBox(ref this.rtfLogSystem);
                this.g_InfoManager.SetNetworkTextBox(ref this.rtfLogNet);
                this.g_InfoManager.SetWarningTextBox(ref this.rtfLogWarning);
                this.g_InfoManager.SetErrorTextBox(ref this.rtfLogError);
                this.g_InfoManager.SetDebugTextBox(ref this.rtfLogDebug);
            }
            catch (Exception ex)
            {
                Console.Write(ex.ToString());
            }

            // check config is exist
            try
            {
                this.funcCheckConfigExists();
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }

            // start day
            this.g_StartApplicationDay = DateTime.Today;

            this.g_InfoManager.General("[App Version] : " + this.Text);
            this.g_InfoManager.General("[Form Load] Start Day : " + this.g_StartApplicationDay.ToString("yyyyMMdd"));

            // frm Config
            try
            {
                this.g_frmPlcConfig = new frmPlcConfig(this.g_ClsPlcConfig, this.g_InfoManager);
                this.g_frmNetworkConfig = new frmNetworkConfig(this.g_ClsNetworkConfig, this.g_InfoManager);
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }
        }

        private void frmTilingController_FormClosed(object sender, FormClosedEventArgs e)
        {

            // log
            try
            {
                if (this.g_InfoManager != null) this.g_InfoManager.Dispose();
            }
            catch (Exception ex) {
                Console.WriteLine(ex.ToString());
            }


        }

        private void frmTilingController_FormClosing(object sender, FormClosingEventArgs e)
        {
            //
            if (this.btnStartDetect.Text == "Stop")
            {
                MessageBox.Show("檢測中，無法關閉程式! 請手動停止檢測後關閉程式\r\nNow detecting, cannot close the application.\r\nPlease stop detection to close.", Common.TILING_NAME);
                // Cancel the Closing event from closing the form.
                e.Cancel = true;
                return;
            }

            // Display a MsgBox asking the user to save changes or abort.
            if (MessageBox.Show("關閉應用程式?\r\nClose the application?", Common.TILING_NAME, MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
            {
                Thread.Sleep(100);
            }
            else
            {
                // Cancel the Closing event from closing the form.
                e.Cancel = true;
            }
        }

        private void tsmiPlcConfig_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_frmPlcConfig == null)
                {
                    this.g_frmPlcConfig = new frmPlcConfig(this.g_ClsPlcConfig, this.g_InfoManager);
                }

                if (!this.g_frmPlcConfig.Visible)
                {
                    // Add the message
                    this.g_frmPlcConfig.Show();
                }
                else
                {
                    this.g_frmPlcConfig.WindowState = FormWindowState.Normal;
                    // Top
                    this.g_frmPlcConfig.BringToFront();
                }
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }
        }

        private void tsmiNetworkConfig_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_frmNetworkConfig == null)
                {
                    this.g_frmNetworkConfig = new frmNetworkConfig(this.g_ClsNetworkConfig, this.g_InfoManager);
                }

                if (!this.g_frmNetworkConfig.Visible)
                {
                    // Add the message
                    this.g_frmNetworkConfig.Show();
                }
                else
                {
                    this.g_frmNetworkConfig.WindowState = FormWindowState.Normal;
                    // Top
                    this.g_frmNetworkConfig.BringToFront();
                }
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }

        }

        private void tsmiAbout_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_frmAbout == null)
                {
                    this.g_frmAbout = new frmAbout();
                }

                if (!this.g_frmAbout.Visible)
                {
                    // Add the message
                    this.g_frmAbout.Show();
                }
                else
                {
                    this.g_frmAbout.WindowState = FormWindowState.Normal;
                    // Top
                    this.g_frmAbout.BringToFront();
                }
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }
        }

        private void btnResetToInitial_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_ClsPlcControl != null)
                {
                    this.g_ClsPlcControl.ResetToInitial();
                }
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }
 
        }

        private void btnSendMsgToDaTest_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.g_ClsNetworkControl == null)
                {
                    this.g_InfoManager.Error("Please connect the DA server first");
                    return;
                }

                int tempPosition = Convert.ToInt32(this.txtDaPosition.Text);
                double tempX = 0;
                double tempY = 0;
                double tempTheta = 0;

                if (this.cboDaCommand.Text.Contains("COARSE"))
                {
                    if (tempPosition != 1 && tempPosition != 9)
                    {
                        this.g_InfoManager.Error("Invalid parameters : COARSE, " + tempPosition);
                        return;
                    }
                    this.funcSendCoarseMsgToDA("", tempPosition, ref tempX, ref tempY, ref tempTheta);
                }
                else if (this.cboDaCommand.Text.Contains("FINE"))
                {
                    string toDaMsg = "FINE";

                    if (tempPosition == 11 && tempPosition == 12 && tempPosition == 13 && tempPosition == 14 &&
                        tempPosition == 21 && tempPosition == 22 && tempPosition == 23 && tempPosition == 24)
                    {
                        toDaMsg = "FINE1";
                    }
                    else if (tempPosition == 51 && tempPosition == 52 && tempPosition == 53 && tempPosition == 54 &&
                        tempPosition == 61 && tempPosition == 62 && tempPosition == 63 && tempPosition == 64)
                    {
                        toDaMsg = "FINE2";
                    }
                    else if (tempPosition == 111 && tempPosition == 112 && tempPosition == 113 && tempPosition == 114 &&
                        tempPosition == 121 && tempPosition == 122 && tempPosition == 123 && tempPosition == 124)
                    {
                        toDaMsg = "FINE3";
                    }
                    else if (tempPosition == 211 && tempPosition == 212 && tempPosition == 213 && tempPosition == 214 &&
                        tempPosition == 221 && tempPosition == 222 && tempPosition == 223 && tempPosition == 224)
                    {
                        toDaMsg = "FINE4";
                    }
                    else
                    {
                        this.g_InfoManager.Error("Invalid parameters : FINE, " + tempPosition);
                        return;
                    }

                    this.funcSendFineMsgToDA(toDaMsg, tempPosition, ref tempX, ref tempY, ref tempTheta);
                }
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            try
            {
                _stRecordMsg_ temp_stRecordMsg_ = new _stRecordMsg_(
                    this.g_ClsRecordControl.m_stRecordMsg_.Count(),
                    DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"), "COARSE", "OK", "0.155", "1.625", "2.1547");

                this.g_ClsRecordControl.RecordAddOneResult(temp_stRecordMsg_, System.DateTime.Today.ToString("yyyyMMdd"));

                this.g_BindingSource.ResetBindings(false);

                try
                {
                    string tempSaveRecordFilePath = this.g_ClsRecordConfig.recordPath + "\\" + this.g_StartApplicationDay.ToString("yyyyMMdd") + "_" + Common.RECORD_RESULT_NAME;
                    ClsRecordControl.WriteXML(this.g_ClsRecordControl, tempSaveRecordFilePath);
                }
                catch (Exception ex)
                {
                    this.g_InfoManager.Error(ex.ToString());
                }

                if (this.g_ClsPlcControl != null)
                {
                    this.g_ClsPlcControl.CheckConfig();
                }
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }





            try
            {
                CommonBase.Network.Request request = new CommonBase.Network.Request();
                CommonBase.Network.Response temp_Response = null;

                // Prepare msg
                request.Command = "FINE1";
                request.Param1 = "11";
                request.Param2 = "";
                request.Param3 = "";
                request.Param4 = "";
                request.Param5 = "";
                request.Param6 = "";
                request.Param7 = "";
                request.Param8 = "";
                request.Param9 = "";

                this.g_ClsNetworkControl.SendMessage(request, ref temp_Response);

                if (temp_Response == null)
                {
                    
                }
                else
                {
                    if (temp_Response.Result == CommonBase.Network.ResponseResult.OK)
                    {
                        this.g_InfoManager.HighLight("P1 : " + temp_Response.Param1);
                        this.g_InfoManager.HighLight("P2 : " + temp_Response.Param2);
                        this.g_InfoManager.HighLight("P3 : " + temp_Response.Param3);
                        this.g_InfoManager.HighLight("P4 : " + temp_Response.Param4);
                        this.g_InfoManager.HighLight("P5 : " + temp_Response.Param5);
                        this.g_InfoManager.HighLight("P6 : " + temp_Response.Param6);
                        this.g_InfoManager.HighLight("P7 : " + temp_Response.Param7);
                        this.g_InfoManager.HighLight("P8 : " + temp_Response.Param8);
                        this.g_InfoManager.HighLight("P9 : " + temp_Response.Param9);
                    }
                    else if (temp_Response.Result == CommonBase.Network.ResponseResult.ERR)
                    {
                        this.g_InfoManager.Error("[Fine] DA response an err msg : " + temp_Response.Param1);
                       
                    }
                    else if (temp_Response.Result == CommonBase.Network.ResponseResult.TIMEOUT)
                    {
                        this.g_InfoManager.Error("[Fine] Receive DA msg TimeOut");
                       
                    }
                }
            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
               
            }

            return;

        }

        private void btnHideLog_Click(object sender, EventArgs e)
        {
            if (this.btnHideLog.Text == "^ ^ ^")
            {
                this.ClientSize = new System.Drawing.Size(640, 430);
                this.btnHideLog.Text = "v v v";
            }
            else
            {
                this.ClientSize = new System.Drawing.Size(640, 725);
                this.btnHideLog.Text = "^ ^ ^";
            }


        }

        private void tmrAlive_Tick(object sender, EventArgs e)
        {

            try
            {
                //
                if (this.g_toggle)
                {
                    this.pnlAliveCheck.BackColor = Color.Green;
                    this.g_toggle = false;
                }
                else
                {
                    this.pnlAliveCheck.BackColor = Color.White;
                    this.g_toggle = true;
                }

                //
                // Reset cnt
                DateTime NowDay = DateTime.Today;  

                TimeSpan ts1 = NowDay - this.g_StartApplicationDay;
                if (ts1.Days > 0)
                {
                    this.g_StartApplicationDay = NowDay;
                    this.g_ClsRecordControl.CheckCurrentDate(this.g_StartApplicationDay.ToString("yyyyMMdd"));

                    this.g_BindingSource.ResetBindings(false);

                    if (this.dtpNowDate.Value != DateTime.Now)
                    {
                        this.dtpNowDate.Value = DateTime.Now;
                    }

                    this.g_InfoManager.General("[Cross Day] : reset cnt");
                }

                // Update
                if (this.g_UpdateRecordInfo)
                {
                    this.g_BindingSource.ResetBindings(false);
                    this.g_UpdateRecordInfo = false;
                }



            }
            catch (Exception ex)
            {
                this.g_InfoManager.Error(ex.ToString());
            }


        }
    }
}
