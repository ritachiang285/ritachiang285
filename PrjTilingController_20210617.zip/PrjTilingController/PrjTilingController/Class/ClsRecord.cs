﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace PrjTilingController.Class
{
    public partial class ClsRecordConfig : CommonBase.Config.BaseConfig<ClsRecordConfig>
    {
        private string classVersion = "ClsRecordConfig_202103191115";

        public string recordPath;

        public int resetCntHour;

        public ClsRecordConfig()
        {
            this.recordPath = "D:\\Tiling\\Record";
            this.resetCntHour = 0;

        }
        protected override bool CheckValue(ClsRecordConfig tmpConfig)
        {
            this.recordPath = tmpConfig.recordPath;

            this.resetCntHour = tmpConfig.resetCntHour;

            //	Read UPDATE
            this.Update = tmpConfig.Update;

            //	Read VERSION
            this.Version = this.classVersion;

            if (this.Version != tmpConfig.Version)
                return false;
            else
                return true;
        }
    }

    public class _stRecordMsg_ : IComparable<_stRecordMsg_>
    {
        public int Order { get; set; }

        public string RecordTime { get; set; }
        public string Command { get; set; }
        public string Response { get; set; }
        public string X { get; set; }
        public string Y { get; set; }
        public string Theta { get; set; }

        public _stRecordMsg_()
        {
            this.Order = 0;

            this.RecordTime = "";
            this.Command = "";
            this.Response = "";

            this.X = "";
            this.Y = "";
            this.Theta = "";
        }

        public _stRecordMsg_(int o_Order, string o_RecordTime, string o_Command, string o_Response,
            string o_X, string o_Y, string o_Theta)
        {
            this.Order = o_Order;

            this.RecordTime = o_RecordTime;
            this.Command = o_Command;
            this.Response = o_Response;
            this.X = o_X;
            this.Y = o_Y;
            this.Theta = o_Theta;
        }

        //public int Compare(_stRecordMsg_ x, _stRecordMsg_ y)
        //{
        //    return (int)x.Order - (int)y.Order;
        //}

        virtual public int CompareTo(_stRecordMsg_ other)
        {
            return Order.CompareTo(other.Order);
        }
    }

    public class ClsRecordControl
    {
        private ClsRecordConfig m_ClsRecordConfig;

        private CommonBase.Logger.InfoManager m_InfoManager = null;

        private string m_CurrentDate;

        public List<_stRecordMsg_> m_stRecordMsg_;

        public ClsRecordControl()
        {
            this.m_ClsRecordConfig = null;

            this.m_InfoManager = null;

            this.m_CurrentDate = System.DateTime.Today.ToString("yyyyMMdd");

            this.m_stRecordMsg_ = new List<_stRecordMsg_> { };
        }

        public ClsRecordControl(ClsRecordConfig o_ClsRecordConfig, string o_nowDate, CommonBase.Logger.InfoManager o_InfoManager)
        {
            this.m_ClsRecordConfig = o_ClsRecordConfig;

            this.m_InfoManager = o_InfoManager;

            this.m_CurrentDate = o_nowDate;

            this.m_stRecordMsg_ = new List<_stRecordMsg_> { };
        }

        private void _resetToInitial(string o_CurrentDate)
        {
            this.m_CurrentDate = o_CurrentDate;

            this.m_stRecordMsg_.Clear();
        }

        public void CheckCurrentDate(string o_CurrentDate)
        {
            // 
            if (this.m_CurrentDate != o_CurrentDate)
            {
                this._resetToInitial(o_CurrentDate);
            }
        }

        public bool RecordAddOneResult(_stRecordMsg_ o_stRecordMsg_, string o_CurrentDate)
        {
            if (o_stRecordMsg_ == null)
            {
                return false;
            }

            // 
            if (this.m_CurrentDate != o_CurrentDate)
            {
                this._resetToInitial(o_CurrentDate);
            }

            //this.m_stRecordMsg_.Add(o_stRecordMsg_);
            this.m_stRecordMsg_.Insert(0, o_stRecordMsg_);

            return true;
        }

        public static ClsRecordControl ReadXML(string fileName)
        {
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(ClsRecordControl));
                StreamReader sr = new StreamReader(fileName, System.Text.Encoding.Default);
                ClsRecordControl m_Object =  (ClsRecordControl)(serializer.Deserialize(sr));
                sr.Close();
                return m_Object;
            }
            catch (Exception ex) {
                throw new Exception("[ClsRecordControl.ReadXML] Read ClsRecordControl XML Error !(" + ex.Message + ")(" + ex.StackTrace + ")");
            }
        }

        public static void WriteXML(ClsRecordControl p_Object, string fileName)
        {
            try
            {
                if (!System.IO.Directory.Exists(System.IO.Path.GetDirectoryName(fileName)))
                {
                    System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(fileName));
                }

                XmlSerializer serializer = new XmlSerializer(typeof(ClsRecordControl));
                StreamWriter sw = new StreamWriter(fileName, false, System.Text.Encoding.Unicode);
                serializer.Serialize(sw, p_Object);
                sw.Close();
            }
            catch (Exception ex) {
                throw new Exception("[ClsRecordControl.WriteXML] Write ClsRecordControl XML Error !(" + ex.Message + ")(" + ex.StackTrace + ")");
            }
        }

    }



}
