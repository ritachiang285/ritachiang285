﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PrjTilingController.Class;

namespace PrjTilingController
{
    public partial class frmPlcConfig : Form
    {
        private ClsPlcConfig m_ClsPlcConfig;
        private ClsPlcConfig m_ClsPlcConfigInline;
        private CommonBase.Logger.InfoManager m_InfoManager;

        public frmPlcConfig(Class.ClsPlcConfig o_ClsPlcConfig, CommonBase.Logger.InfoManager o_InfoManager)
        {
            this.m_ClsPlcConfig = null;

            this.m_ClsPlcConfigInline = o_ClsPlcConfig;

            this.m_InfoManager = o_InfoManager;

            InitializeComponent();
        }

        public void UpdateObject(Class.ClsPlcConfig o_ClsPlcConfig)
        {
            this.m_ClsPlcConfigInline = o_ClsPlcConfig;
        }

        private void OnSaveConfig(object sender, EventArgs e)
        {
            if (this.m_ClsPlcConfigInline != null)
            {
                this.m_ClsPlcConfigInline.UpdateParams(this.m_ClsPlcConfig);
            }

            //
            this.m_ClsPlcConfig.m_ClientWidth = this.ClientSize.Width;
            this.m_ClsPlcConfig.m_ClientHeight = this.ClientSize.Height;

            this.m_ClsPlcConfig.WriteWithoutCrypto(Common.CONFIG_FOLDER + Common.PLC_CONFIG_NAME, true);
            //MessageBox.Show(String.Format("參數儲存完畢[{0}]", Common.CONFIG_FOLDER + Common.PLC_CONFIG_NAME));
        }

        private void funcAddButton()
        {
            ToolStripButton objButton = null;

            foreach (Control objControl in this.propertyGrid1.Controls)
            {
                ToolStrip objToolStrip = objControl as ToolStrip;

                if (objToolStrip != null)
                {                    
                    for (int i = 0; i < objToolStrip.Items.Count; i++)
                    {
                        objToolStrip.Items[i].Visible = false;
                    }

                    //
                    objButton = new ToolStripButton
                    {
                        CheckOnClick = false,
                        DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image,
                        Image = Properties.Resources.Save,
                        Name = "btnSave",
                        Size = new System.Drawing.Size(23, 22),
                        Text = "儲存參數",
                        ToolTipText = "儲存參數"
                    };
                    objButton.Click += new EventHandler(this.OnSaveConfig);
                    objToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] { objButton });

                    //

                }
            }
        }

        private void frmPlcConfig_Load(object sender, EventArgs e)
        {
            try
            {

                if (!File.Exists(Common.CONFIG_FOLDER + Common.PLC_CONFIG_NAME))
                {
                    ClsPlcConfig temp_ClsPlcConfig = new ClsPlcConfig();
                    temp_ClsPlcConfig.WriteWithoutCrypto(Common.CONFIG_FOLDER + Common.PLC_CONFIG_NAME, true);
                    this.m_InfoManager.HighLight("Plc config not exist, new one : " + Common.CONFIG_FOLDER + Common.PLC_CONFIG_NAME);
                }

                this.m_ClsPlcConfig = new ClsPlcConfig();
                this.m_ClsPlcConfig.ReadWithoutCrypto(Common.CONFIG_FOLDER + Common.PLC_CONFIG_NAME);

                this.propertyGrid1.SelectedObject = this.m_ClsPlcConfig;
                this.propertyGrid1.PropertySort = PropertySort.NoSort;

                this.funcAddButton();

                this.propertyGrid1.ExpandAllGridItems();

                //              
                this.ClientSize = new System.Drawing.Size(
                    this.m_ClsPlcConfig.m_ClientWidth,
                    this.m_ClsPlcConfig.m_ClientHeight);

            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error(ex.ToString());
            }
        }

        private void frmPlcConfig_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }
    }
}
