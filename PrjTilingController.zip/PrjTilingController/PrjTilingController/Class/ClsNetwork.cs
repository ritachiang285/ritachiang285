﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace PrjTilingController.Class
{

    public enum EnumDaCommand
    {
        COARSE = 0,
        FINE
    };


    public partial class ClsNetworkConfig : CommonBase.Config.BaseConfig<ClsNetworkConfig>
    {
        private string classVersion = "ClsNetworkConfig_202103191115";

        public bool Enable { get; set; }

        //[DisplayName("0.1 ServerIp"), Description("")]
        public string ServerIp { get; set; }

        //[DisplayName("0.2 SeverPort"), Description("")]
        public int SeverPort { get; set; }

        //[DisplayName("0.3 ReceiveTimeOut"), Description("")]
        
        public int ReceiveTimeOut { get; set; }

        public int m_ClientWidth;
        public int m_ClientHeight;


        public ClsNetworkConfig()
        {
            this.Enable = true;

            this.ServerIp = "127.0.0.1";

            this.SeverPort = 9001;

            this.ReceiveTimeOut = 3000;

            this.m_ClientWidth = 340;
            this.m_ClientHeight = 380;
        }

        public void UpdateParams(ClsNetworkConfig o_ClsNetworkConfig)
        {
            this.Enable = o_ClsNetworkConfig.Enable;

            this.ServerIp = o_ClsNetworkConfig.ServerIp;

            this.SeverPort = o_ClsNetworkConfig.SeverPort;

            this.ReceiveTimeOut = o_ClsNetworkConfig.ReceiveTimeOut;

            this.m_ClientWidth = o_ClsNetworkConfig.m_ClientWidth;

            this.m_ClientHeight = o_ClsNetworkConfig.m_ClientHeight;

        }

        protected override bool CheckValue(ClsNetworkConfig tmpConfig)
        {
            this.Enable = tmpConfig.Enable;

            this.ServerIp = tmpConfig.ServerIp;

            this.SeverPort = tmpConfig.SeverPort;

            this.ReceiveTimeOut = tmpConfig.ReceiveTimeOut;

            this.m_ClientWidth = tmpConfig.m_ClientWidth;
            this.m_ClientHeight = tmpConfig.m_ClientHeight;

            //	Read UPDATE
            this.Update = tmpConfig.Update;

            //	Read VERSION
            this.Version = this.classVersion;

            if (this.Version != tmpConfig.Version)
                return false;
            else
                return true;

        }
    }

    public class ClsNetworkControl
    {
        private ClsNetworkConfig m_ClsNetworkConfig = null;

        private CommonBase.Logger.InfoManager m_InfoManager = null;

        private CommonBase.Network.Client m_Client = null;

        public ClsNetworkControl(ClsNetworkConfig o_ClsNetworkConfig, CommonBase.Logger.InfoManager o_InfoManager)
        {
            this.m_ClsNetworkConfig = o_ClsNetworkConfig;

            this.m_InfoManager = o_InfoManager;
        }
        public void StratConnect()
        {           
            try
            {
                if (!this.m_ClsNetworkConfig.Enable)
                {
                    return;
                }

                // New client object.
                this.m_Client = new CommonBase.Network.Client(
                this.m_ClsNetworkConfig.ServerIp,
                this.m_ClsNetworkConfig.SeverPort);

                // start to connect
                this.m_Client.StartConnect();
            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error(ex.ToString());
            }
        }

        public void StopConnect()
        {
            try
            {
                if (!this.m_ClsNetworkConfig.Enable)
                {
                    return;
                }

                // Disconnect Client and dispose it.
                this.m_Client.StopConnect();
                this.m_Client.Dispose();
            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error(ex.ToString());
            }
        }

        public void SendMessage(
            CommonBase.Network.Request o_request,
            ref CommonBase.Network.Response o_response)
        {
            try 
            {
                if (!this.m_ClsNetworkConfig.Enable)
                {
                    this.m_InfoManager.Error("No connect DA server");
                    return;
                }

                // Send request and wait for xxxx ms to recieve response
                o_response = this.m_Client.SendRequest(o_request, this.m_ClsNetworkConfig.ReceiveTimeOut);
            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error(ex.ToString());
            }
        }



    }




}
