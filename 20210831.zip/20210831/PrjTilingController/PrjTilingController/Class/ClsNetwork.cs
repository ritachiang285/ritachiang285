﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace PrjTilingController.Class
{

    public enum EnumDaCommand
    {
        COARSE = 0,
        FINE,
        Laminater
    };


    public partial class ClsNetworkConfig : CommonBase.Config.BaseConfig<ClsNetworkConfig>
    {
        private string classVersion = "ClsNetworkConfig_202103191115";

        public bool Enable { get; set; }

        //[DisplayName("0.1 ServerIp"), Description("")]
        public string ServerIp { get; set; }

        //[DisplayName("0.2 SeverPort"), Description("")]
        public int SeverPort { get; set; }

        //[DisplayName("0.3 ReceiveTimeOut"), Description("")]
        public int ReceiveTimeOut { get; set; }

        public bool Enable_COARSE { get; set; }

        //[DisplayName("0.4 ServerIp_COARSE"), Description("")]
        public string ServerIp_COARSE { get; set; }

        //[DisplayName("0.5 SeverPort_COARSE"), Description("")]
        public int SeverPort_COARSE { get; set; }

        public bool Enable_Laminater { get; set; }

        //[DisplayName("0.6 ServerIp_Laminater"), Description("")]
        public string ServerIp_Laminater { get; set; }

        //[DisplayName("0.7 SeverPort_Laminater"), Description("")]
        public int SeverPort_Laminater { get; set; }



        public int m_ClientWidth;
        public int m_ClientHeight;


        public ClsNetworkConfig()
        {
            this.Enable = true;

            this.ServerIp = "127.0.0.1";

            this.SeverPort = 9001;

            this.Enable_COARSE = true;

            this.ServerIp_COARSE = "127.0.0.1";

            this.SeverPort_COARSE = 8001;

            this.Enable_Laminater = true;

            this.ServerIp_Laminater = "127.0.0.1";

            this.SeverPort_Laminater = 7001;

            this.ReceiveTimeOut = 3000;

            this.m_ClientWidth = 340;
            this.m_ClientHeight = 380;
        }

        public void UpdateParams(ClsNetworkConfig o_ClsNetworkConfig)
        {
            this.Enable = o_ClsNetworkConfig.Enable;

            this.ServerIp = o_ClsNetworkConfig.ServerIp;

            this.SeverPort = o_ClsNetworkConfig.SeverPort;

            this.Enable = o_ClsNetworkConfig.Enable;

            this.ReceiveTimeOut = o_ClsNetworkConfig.ReceiveTimeOut;

            this.Enable_COARSE = o_ClsNetworkConfig.Enable_COARSE;

            this.ServerIp_COARSE = o_ClsNetworkConfig.ServerIp_COARSE;

            this.SeverPort_COARSE = o_ClsNetworkConfig.SeverPort_COARSE;

            this.Enable_Laminater = o_ClsNetworkConfig.Enable_Laminater;

            this.ServerIp_Laminater = o_ClsNetworkConfig.ServerIp_Laminater;

            this.SeverPort_Laminater = o_ClsNetworkConfig.SeverPort_Laminater;

            this.m_ClientWidth = o_ClsNetworkConfig.m_ClientWidth;

            this.m_ClientHeight = o_ClsNetworkConfig.m_ClientHeight;

        }

        protected override bool CheckValue(ClsNetworkConfig tmpConfig)
        {
            this.Enable = tmpConfig.Enable;

            this.ServerIp = tmpConfig.ServerIp;

            this.SeverPort = tmpConfig.SeverPort;

            this.ReceiveTimeOut = tmpConfig.ReceiveTimeOut;

            this.Enable_COARSE = tmpConfig.Enable_COARSE;

            this.ServerIp_COARSE = tmpConfig.ServerIp_COARSE;

            this.SeverPort_COARSE = tmpConfig.SeverPort_COARSE;

            this.Enable_Laminater = tmpConfig.Enable_Laminater;

            this.ServerIp_Laminater = tmpConfig.ServerIp_Laminater;

            this.SeverPort_Laminater = tmpConfig.SeverPort_Laminater;


            this.m_ClientWidth = tmpConfig.m_ClientWidth;
            this.m_ClientHeight = tmpConfig.m_ClientHeight;

            //	Read UPDATE
            this.Update = tmpConfig.Update;

            //	Read VERSION
            this.Version = this.classVersion;

            if (this.Version != tmpConfig.Version)
                return false;
            else
                return true;

        }
    }

    public class ClsNetworkControl
    {
        private ClsNetworkConfig m_ClsNetworkConfig = null;

        private CommonBase.Logger.InfoManager m_InfoManager = null;

        private CommonBase.Network.Client m_Client = null;

        private CommonBase.Network.Client m_Client_COARSE = null;

        private CommonBase.Network.Client m_Client_Laminater = null;
        public ClsNetworkControl(ClsNetworkConfig o_ClsNetworkConfig, CommonBase.Logger.InfoManager o_InfoManager)
        {
            this.m_ClsNetworkConfig = o_ClsNetworkConfig;

            this.m_InfoManager = o_InfoManager;
        }
        public void StratConnect()
        {           
            try
            {
                // New client object.
                if (this.m_ClsNetworkConfig.Enable)
                {
                    this.m_Client = new CommonBase.Network.Client(
                  this.m_ClsNetworkConfig.ServerIp,
                  this.m_ClsNetworkConfig.SeverPort);
                    this.m_Client.StartConnect();
                }



                if (this.m_ClsNetworkConfig.Enable_COARSE)
                {
                    this.m_Client_COARSE = new CommonBase.Network.Client(
                this.m_ClsNetworkConfig.ServerIp_COARSE,
                this.m_ClsNetworkConfig.SeverPort_COARSE);
                    this.m_Client_COARSE.StartConnect();
                }

                if (this.m_ClsNetworkConfig.Enable_Laminater)
                {
                    this.m_Client_Laminater = new CommonBase.Network.Client(
                this.m_ClsNetworkConfig.ServerIp_Laminater,
                this.m_ClsNetworkConfig.SeverPort_Laminater);
                    this.m_Client_Laminater.StartConnect();
                }
                // start to connect


            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error(ex.ToString());
            }
        }

        public void StopConnect()
        {
            try
            {
                if (this.m_ClsNetworkConfig.Enable)
                {
                    // Disconnect Client and dispose it.
                    this.m_Client.StopConnect();
                    this.m_Client.Dispose();
                }
                else if   (this.m_ClsNetworkConfig.Enable_COARSE)
                    {
                    // Disconnect Client and dispose it.
                    this.m_Client_COARSE.StopConnect();
                        this.m_Client_COARSE.Dispose();
                    }

                else if (this.m_ClsNetworkConfig.Enable_Laminater)
                {
                    // Disconnect Client and dispose it.
                    this.m_Client_Laminater.StopConnect();
                    this.m_Client_Laminater.Dispose();
                }




            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error(ex.ToString());
            }
        }

        public void SendMessage(
            CommonBase.Network.Request o_request,
            ref CommonBase.Network.Response o_response)
        {
            try 
            {
                if (!this.m_ClsNetworkConfig.Enable  && !this.m_ClsNetworkConfig.Enable_COARSE && !this.m_ClsNetworkConfig.Enable_Laminater)
                {
                    this.m_InfoManager.Error("No connect DA server");
                    return;
                    
                }


                // Send request and wait for xxxx ms to recieve response

                if (this.m_ClsNetworkConfig.Enable)
                    {
                    o_response = this.m_Client.SendRequest(o_request, this.m_ClsNetworkConfig.ReceiveTimeOut);
                }
                else if (this.m_ClsNetworkConfig.Enable_COARSE)
                {
                    o_response = this.m_Client_COARSE.SendRequest(o_request, this.m_ClsNetworkConfig.ReceiveTimeOut);
                }
                else if (this.m_ClsNetworkConfig.Enable_Laminater)
                {
                    o_response = this.m_Client_Laminater.SendRequest(o_request, this.m_ClsNetworkConfig.ReceiveTimeOut);
                }

            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error(ex.ToString());
            }
        }



    }




}
