﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Threading;

namespace PrjTilingController.Class
{
    public enum EnumPlcConnectInterface
    {
        ETHERNET = 0,
		CPU
    };

    [TypeConverter(typeof(ExpandableObjectConverter))]
    public class _stPlcCpu_ : ExpandableObjectConverter
    {
        public string PlcIpAddress { get; set; }
        public int TimeOut { get; set; }
        public bool IsTCP { get; set; }

        public _stPlcCpu_()
        {
            this.PlcIpAddress = "192.168.3.120";
            this.TimeOut = 1000;
            this.IsTCP = false;
        }

       public void UpdateParams(_stPlcCpu_ o_stPlcCpu_)
        {
            this.PlcIpAddress = o_stPlcCpu_.PlcIpAddress;

            this.TimeOut = o_stPlcCpu_.TimeOut;

            this.IsTCP = o_stPlcCpu_.IsTCP;
        }

        public override string ToString()
        {
            return "----------";
        }
    }

    [TypeConverter(typeof(ExpandableObjectConverter))]
    public class _stPlcEther_ : ExpandableObjectConverter
    {
		public string PlcIpAddress { get; set; }
		public int PlcNetworkNo { get; set; }
		public int PlcStationNo { get; set; }
		public int PcStationNo { get; set; }
		public int PortNo { get; set; }
		public int TimeOut { get; set; }
		public bool IsTCP { get; set; }
        public _stPlcEther_()
        {
            this.PlcIpAddress = "192.168.3.1";
            this.PlcNetworkNo = 1;
            this.PlcStationNo = 1;
            this.PcStationNo = 2;
            this.PortNo = 5002;
            this.TimeOut = 1000;
            this.IsTCP = false;
        }

        public void UpdateParams(_stPlcEther_ o_stPlcEther_)
        {
            this.PlcIpAddress = o_stPlcEther_.PlcIpAddress;

            this.PlcNetworkNo = o_stPlcEther_.PlcNetworkNo;

            this.PlcStationNo = o_stPlcEther_.PlcStationNo;

            this.PcStationNo = o_stPlcEther_.PcStationNo;

            this.PortNo = o_stPlcEther_.PortNo;

            this.TimeOut = o_stPlcEther_.TimeOut;

            this.IsTCP = o_stPlcEther_.IsTCP;
        }

        public override string ToString()
        {
            return "----------";
        }
    };

    [TypeConverter(typeof(ExpandableObjectConverter))]
    public class _stCoarseDevice_ : ExpandableObjectConverter
    {
        public bool Enable { get; set; }

        public string ReadyRequest_Get { get; set; }
        public string Ready_Set { get; set; }

        public string MeasureRequest_Get { get; set; }
        public string PositionInfo_Get { get; set; }

        public string MeasureFinish_Set { get; set; }
        public string MeasureNG_Set { get; set; }
        public string MeasureNG1_Set { get; set; }
        public string MeasureResultX_Set { get; set; }
        public string MeasureResultY_Set { get; set; }
        public string MeasureResultTheta_Set { get; set; }

        public string ReceiveMeasure_Get { get; set; }

        public int ScanInterval { get; set; }

        public _stCoarseDevice_()
        {
            this.Enable = true;

            this.ReadyRequest_Get = "M3011";
            this.Ready_Set = "M2011";
            this.MeasureRequest_Get = "M3014";
            this.PositionInfo_Get = "D2000";

            this.MeasureFinish_Set = "M2014";
            this.MeasureNG_Set = "M2015";
            this.MeasureNG1_Set = "M2016";
            this.MeasureResultX_Set = "D1000";
            this.MeasureResultY_Set = "D1100";
            this.MeasureResultTheta_Set = "D1200";

            this.ReceiveMeasure_Get = "M3015";

            this.ScanInterval = 50;
        }

        public void UpdateParams(_stCoarseDevice_ o_stCoarseDevice_)
        {
            this.Enable = o_stCoarseDevice_.Enable;

            this.ReadyRequest_Get = o_stCoarseDevice_.ReadyRequest_Get;
            this.Ready_Set = o_stCoarseDevice_.Ready_Set;
            this.MeasureRequest_Get = o_stCoarseDevice_.MeasureRequest_Get;
            this.PositionInfo_Get = o_stCoarseDevice_.PositionInfo_Get;

            this.MeasureFinish_Set = o_stCoarseDevice_.MeasureFinish_Set;
            this.MeasureNG_Set = o_stCoarseDevice_.MeasureNG_Set;
            this.MeasureNG1_Set = o_stCoarseDevice_.MeasureNG1_Set;
            this.MeasureResultX_Set = o_stCoarseDevice_.MeasureResultX_Set;
            this.MeasureResultY_Set = o_stCoarseDevice_.MeasureResultY_Set;
            this.MeasureResultTheta_Set = o_stCoarseDevice_.MeasureResultTheta_Set;

            this.ReceiveMeasure_Get = o_stCoarseDevice_.ReceiveMeasure_Get;

            this.ScanInterval = o_stCoarseDevice_.ScanInterval;
        }

        public override string ToString()
        {
            return "----------";
        }
    }

    [TypeConverter(typeof(ExpandableObjectConverter))]
    public class _stFineDevice_ : ExpandableObjectConverter
    {
        public bool Enable { get; set; }

        public string ReadyRequest_Get { get; set; }

        public string Ready_Set { get; set; }

        public string MeasureRequest_Get { get; set; }
        public string PositionInfo_Get { get; set; }

        public string MeasureFinish_Set { get; set; }
        public string MeasureNG_Set { get; set; }
        public string MeasureResultX_Set { get; set; }
        public string MeasureResultY_Set { get; set; }
        public string MeasureResultTheta_Set { get; set; }

        public string ReceiveMeasure_Get { get; set; }

        public string CheckNG_Set { get; set; }


        public string ReviewNG_Set { get; set; }

        public int ScanInterval { get; set; }

        public _stFineDevice_()
        {
            this.Enable = true;

            this.ReadyRequest_Get = "M3021";
            this.Ready_Set = "M2021";
            this.MeasureRequest_Get = "M3024";
            this.PositionInfo_Get = "D2100";

            this.MeasureFinish_Set = "M2024";
            this.MeasureNG_Set = "M2025";
            this.MeasureResultX_Set = "D1010";
            this.MeasureResultY_Set = "D1110";
            this.MeasureResultTheta_Set = "D1210";

            this.ReceiveMeasure_Get = "M3025";
            this.CheckNG_Set = "M2026";

            this.ReviewNG_Set = "M2030";

            this.ScanInterval = 50;
        }

        public void UpdateParams(_stFineDevice_ o_stFineDevice_)
        {
            this.Enable = o_stFineDevice_.Enable;
            this.Ready_Set = o_stFineDevice_.Ready_Set;
            this.MeasureRequest_Get = o_stFineDevice_.MeasureRequest_Get;
            this.PositionInfo_Get = o_stFineDevice_.PositionInfo_Get;

            this.MeasureFinish_Set = o_stFineDevice_.MeasureFinish_Set;
            this.MeasureNG_Set = o_stFineDevice_.MeasureNG_Set;
            this.MeasureResultX_Set = o_stFineDevice_.MeasureResultX_Set;
            this.MeasureResultY_Set = o_stFineDevice_.MeasureResultY_Set;
            this.MeasureResultTheta_Set = o_stFineDevice_.MeasureResultTheta_Set;

            this.ReceiveMeasure_Get = o_stFineDevice_.ReceiveMeasure_Get;
            this.CheckNG_Set = o_stFineDevice_.CheckNG_Set;

            this.ReviewNG_Set = o_stFineDevice_.ReviewNG_Set;

            this.ScanInterval = o_stFineDevice_.ScanInterval;
        }
        public override string ToString()
        {
            return "----------";
        }
    }

    [TypeConverter(typeof(ExpandableObjectConverter))]
    public class _stLaminaterDevice_ : ExpandableObjectConverter
    {
        public bool Enable { get; set; }

        public string ReadyRequest_Get { get; set; }

        public string Ready_Set { get; set; }

        public string MeasureRequest_Get { get; set; }
        public string PositionInfo_Get { get; set; }

        public string MeasureFinish_Set { get; set; }
        public string MeasureNG_Set { get; set; }
        public string MeasureResultX_Set { get; set; }
        public string MeasureResultY_Set { get; set; }
        public string MeasureResultTheta_Set { get; set; }

        public string ReceiveMeasure_Get { get; set; }

        public string CheckNG_Set { get; set; }


        public string ReviewNG_Set { get; set; }

        public int ScanInterval { get; set; }

        public _stLaminaterDevice_()
        {
            this.Enable = true;

            this.ReadyRequest_Get = "M3111";
            this.Ready_Set = "M2111";
            this.MeasureRequest_Get = "M3114";
            this.PositionInfo_Get = "D2010";

            this.MeasureFinish_Set = "M2114";
            this.MeasureNG_Set = "M2116";
            this.MeasureResultX_Set = "D1000";
            this.MeasureResultY_Set = "D1100";
            this.MeasureResultTheta_Set = "D1200";

            this.ReceiveMeasure_Get = "M3115";
            this.CheckNG_Set = "M2117";

            this.ReviewNG_Set = "M2130";

            this.ScanInterval = 50;
        }

        public void UpdateParams(_stLaminaterDevice_ o_stLaminaterDevice_)
        {
            this.Enable = o_stLaminaterDevice_.Enable;
            this.Ready_Set = o_stLaminaterDevice_.Ready_Set;
            this.MeasureRequest_Get = o_stLaminaterDevice_.MeasureRequest_Get;
            this.PositionInfo_Get = o_stLaminaterDevice_.PositionInfo_Get;

            this.MeasureFinish_Set = o_stLaminaterDevice_.MeasureFinish_Set;
            this.MeasureNG_Set = o_stLaminaterDevice_.MeasureNG_Set;
            this.MeasureResultX_Set = o_stLaminaterDevice_.MeasureResultX_Set;
            this.MeasureResultY_Set = o_stLaminaterDevice_.MeasureResultY_Set;
            this.MeasureResultTheta_Set = o_stLaminaterDevice_.MeasureResultTheta_Set;

            this.ReceiveMeasure_Get = o_stLaminaterDevice_.ReceiveMeasure_Get;
            this.CheckNG_Set = o_stLaminaterDevice_.CheckNG_Set;

            this.ReviewNG_Set = o_stLaminaterDevice_.ReviewNG_Set;

            this.ScanInterval = o_stLaminaterDevice_.ScanInterval;
        }
        public override string ToString()
        {
            return "----------";
        }
    }

    public partial class ClsPlcConfig : CommonBase.Config.BaseConfig<ClsPlcConfig>
    {
        private string classVersion = "ClsPlcConfig_202103191115";


        [DisplayName("0.0 Plc Connection Interface"), Description("The Plc Connection Interface, one of Cpu, Ethernet")]
        public EnumPlcConnectInterface m_EnumPlcConnectInterface { get; set; }

        [DisplayName("0.1 Plc Cpu Setting"), Description("The Plc Cpu Setting")]
        public _stPlcCpu_ m_stPlcCpu_ { get; set; }

        [DisplayName("0.2 Plc Ethernet Setting"), Description("The Plc Ethernet Setting")]
        public _stPlcEther_ m_stPlcEther_ { get; set; }

        [DisplayName("0.3 Heart Beat"), Description("The Device of PC Heart Beat")]
        public string m_HeartBeatDevice { get; set; }

        [DisplayName("0.4 Meachine Error"), Description("The Device of Machine Error")]
        public string m_MeachineError { get; set; }

        //
        [DisplayName("0.5 Frame ID"), Description("The Device of Frame ID")]
        public string m_FrameID { get; set; }

        [DisplayName("0.6 Frame ID Length"), Description("The Get Length of Frame ID")]
        public int m_FrameIdLength { get; set; }

        [DisplayName("0.7 Frame ID Little End"), Description("Frame ID is Little End or not")]
        public bool m_FrameIdLittleEnd { get; set; }

        //
        [DisplayName("0.8 Glass Panel ID"), Description("The Device of Glass Panel ID")]
        public string m_GlassPanelID { get; set; }

        [DisplayName("0.9 Glass Panel ID Length"), Description("The Get Length of Glass Panel ID")]
        public int m_GlassPanelIdLength { get; set; }

        [DisplayName("0.10 Glass Panel ID Little End"), Description("Glass Panel ID is Little End or not")]
        public bool m_GlassPanelIdLittleEnd { get; set; }

        //
        [DisplayName("0.11 Coarse Device"), Description("The Device of Coarse Group")]
        public _stCoarseDevice_ m_stCoarseDevice_ { get; set; }

        [DisplayName("0.12 Find Device"), Description("The Device of Fine Group")]
        public _stFineDevice_ m_stFineDevice_ { get; set; }

        //
        [DisplayName("0.13 Laminater Device"), Description("The Device of Laminater Group")]
        public _stLaminaterDevice_ m_stLaminaterDevice_ { get; set; }


        public int m_ClientWidth;
        public int m_ClientHeight;


        public ClsPlcConfig()
        {
            this.m_EnumPlcConnectInterface = EnumPlcConnectInterface.ETHERNET;
            this.m_stPlcCpu_ = new _stPlcCpu_();
            this.m_stPlcEther_ = new _stPlcEther_();

            this.m_HeartBeatDevice = "M2000";

            this.m_MeachineError = "";

            this.m_MeachineError = "";
            this.m_FrameID = "D2200";
            this.m_FrameIdLength = 20;
            this.m_FrameIdLittleEnd = false;

            this.m_GlassPanelID = "D2300";
            this.m_GlassPanelIdLength = 20;
            this.m_GlassPanelIdLittleEnd = false;

            this.m_stCoarseDevice_ = new _stCoarseDevice_();
            this.m_stFineDevice_ = new _stFineDevice_();
            this.m_stLaminaterDevice_ = new _stLaminaterDevice_();

            this.m_ClientWidth = 340;
            this.m_ClientHeight = 640;
        }

        public void UpdateParams(ClsPlcConfig o_ClsPlcConfig)
        {
            this.m_EnumPlcConnectInterface = o_ClsPlcConfig.m_EnumPlcConnectInterface;

            this.m_stPlcCpu_.UpdateParams(o_ClsPlcConfig.m_stPlcCpu_);
            this.m_stPlcEther_.UpdateParams(o_ClsPlcConfig.m_stPlcEther_);

            this.m_HeartBeatDevice = o_ClsPlcConfig.m_HeartBeatDevice;

            this.m_MeachineError = o_ClsPlcConfig.m_MeachineError;

            this.m_FrameID = o_ClsPlcConfig.m_FrameID;
            this.m_FrameIdLength = o_ClsPlcConfig.m_FrameIdLength;
            this.m_FrameIdLittleEnd = o_ClsPlcConfig.m_FrameIdLittleEnd;

            this.m_GlassPanelID = o_ClsPlcConfig.m_GlassPanelID;
            this.m_GlassPanelIdLength = o_ClsPlcConfig.m_GlassPanelIdLength;
            this.m_GlassPanelIdLittleEnd = o_ClsPlcConfig.m_GlassPanelIdLittleEnd;

            this.m_stCoarseDevice_.UpdateParams(o_ClsPlcConfig.m_stCoarseDevice_);
            this.m_stFineDevice_.UpdateParams(o_ClsPlcConfig.m_stFineDevice_);
            this.m_stLaminaterDevice_.UpdateParams(o_ClsPlcConfig.m_stLaminaterDevice_);

            this.m_ClientWidth = o_ClsPlcConfig.m_ClientWidth;
            this.m_ClientHeight = o_ClsPlcConfig.m_ClientHeight;
        }

        protected override bool CheckValue(ClsPlcConfig tmpConfig)
		{
            this.m_EnumPlcConnectInterface = tmpConfig.m_EnumPlcConnectInterface;

            this.m_stPlcEther_ = tmpConfig.m_stPlcEther_;

            this.m_stPlcCpu_ = tmpConfig.m_stPlcCpu_;

            this.m_stCoarseDevice_ = tmpConfig.m_stCoarseDevice_;

            this.m_stFineDevice_ = tmpConfig.m_stFineDevice_;

            this.m_HeartBeatDevice = tmpConfig.m_HeartBeatDevice;

            this.m_MeachineError = tmpConfig.m_MeachineError;

            this.m_FrameID = tmpConfig.m_FrameID;
            this.m_FrameIdLength = tmpConfig.m_FrameIdLength;
            this.m_FrameIdLittleEnd = tmpConfig.m_FrameIdLittleEnd;

            this.m_GlassPanelID = tmpConfig.m_GlassPanelID;
            this.m_GlassPanelIdLength = tmpConfig.m_GlassPanelIdLength;
            this.m_GlassPanelIdLittleEnd = tmpConfig.m_GlassPanelIdLittleEnd;


            this.m_ClientWidth = tmpConfig.m_ClientWidth;
            this.m_ClientHeight = tmpConfig.m_ClientHeight;


            //	Read UPDATE
            this.Update = tmpConfig.Update;

			//	Read VERSION
			this.Version = this.classVersion;

			if (this.Version != tmpConfig.Version)
				return false;
			else
				return true;

        }

    }

    class ClsPlcControl
    {
        public event funcSendCoarseMsgToDACallBack funcSendCoarseMsgToDA = null;
        public event funcSendFineMsgToDACallBack funcSendFineMsgToDA = null;
        public event funcSendLaminaterMsgToDACallBack funcSendLaminaterMsgToDA = null;

        public event funcChangeCurrentStatusCallBack funcChangeCurrentStatus = null;

        private ClsPlcConfig m_ClsPlcConfig = null;

        private CommonBase.Logger.InfoManager m_InfoManager = null;

        //
        private Mitsubishi.Ether.MxQJ71E71UDP m_MxQJ71E71UDP = null;
		private Mitsubishi.Ether.MxQJ71E71TCP m_MxQJ71E71TCP = null;

		private Mitsubishi.Ether.MxQNUDECPUUDP m_MxQNUDECPUUDP = null;
		private Mitsubishi.Ether.MxQNUDECPUTCP m_MxQNUDECPUTCP = null;

        //
        private bool m_StartCoarseCapture = false;
        private bool m_StartFineCapture = false;
        private bool m_StartLaminaterCapture = false;
        //
        private int _getPlcValueBit(string o_Device, ref ushort o_Data)
        {
            int RtnCode = 0;

            if (o_Device == "" || o_Device == "NULL" || o_Device == "-1")
            {
                return RtnCode;
            }

            Monitor.Enter(this);
            try
            {
                switch ((int)this.m_ClsPlcConfig.m_EnumPlcConnectInterface)
                {
                    case (int)EnumPlcConnectInterface.ETHERNET:
                        {
                            if (this.m_ClsPlcConfig.m_stPlcEther_.IsTCP)
                            {
                                o_Data = this.m_MxQJ71E71TCP.GetDevice(o_Device);
                            }
                            else
                            {
                                o_Data = this.m_MxQJ71E71UDP.GetDevice(o_Device);
                            }
                        }
                        break;

                    case (int)EnumPlcConnectInterface.CPU:
                        {
                            if (this.m_ClsPlcConfig.m_stPlcCpu_.IsTCP)
                            {
                                o_Data = this.m_MxQNUDECPUTCP.GetDevice(o_Device);
                            }
                            else
                            {
                                o_Data = this.m_MxQNUDECPUUDP.GetDevice(o_Device);
                            }
                        }
                        break;

                    default:
                        break;

                }
            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error(ex.ToString());
                RtnCode = -1;
            }
            finally
            {
                Monitor.Exit(this);
            }

            return RtnCode;
        }

        private int _setPlcValueBit(string o_Device, ushort o_Data)
        {
            int RtnCode = 0;

            if (o_Device == "" || o_Device == "NULL" || o_Device == "-1")
            {
                return RtnCode;
            }

            Monitor.Enter(this);
            try
            {
                switch ((int)this.m_ClsPlcConfig.m_EnumPlcConnectInterface)
                {
                    case (int)EnumPlcConnectInterface.ETHERNET:
                        {
                            if (this.m_ClsPlcConfig.m_stPlcEther_.IsTCP)
                            {
                                this.m_MxQJ71E71TCP.SetDevice(o_Device, o_Data);
                            }
                            else
                            {
                                this.m_MxQJ71E71UDP.SetDevice(o_Device, o_Data);
                            }
                        }
                        break;

                    case (int)EnumPlcConnectInterface.CPU:
                        {
                            if (this.m_ClsPlcConfig.m_stPlcCpu_.IsTCP)
                            {
                                this.m_MxQNUDECPUTCP.SetDevice(o_Device, o_Data);
                            }
                            else
                            {
                                this.m_MxQNUDECPUUDP.SetDevice(o_Device, o_Data);
                            }
                        }
                        break;

                    default:
                        break;

                }
            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error(ex.ToString());
                RtnCode = -1;
            }
            finally
            {
                Monitor.Exit(this);
            }

            return RtnCode;
        }

        private int _getPlcValueDouble(string o_Device, ref double o_Data)
        {
            int RtnCode = 0;

            if (o_Device == "" || o_Device == "NULL" || o_Device == "-1")
            {
                return RtnCode;
            }

            Monitor.Enter(this);
            try
            {
                switch ((int)this.m_ClsPlcConfig.m_EnumPlcConnectInterface)
                {
                    case (int)EnumPlcConnectInterface.ETHERNET:
                        {
                            if (this.m_ClsPlcConfig.m_stPlcEther_.IsTCP)
                            {
                                o_Data = this.m_MxQJ71E71TCP.ReadDouble(o_Device);
                            }
                            else
                            {
                                o_Data = this.m_MxQJ71E71UDP.ReadDouble(o_Device);
                            }
                        }
                        break;

                    case (int)EnumPlcConnectInterface.CPU:
                        {
                            if (this.m_ClsPlcConfig.m_stPlcCpu_.IsTCP)
                            {
                                o_Data = this.m_MxQNUDECPUTCP.ReadDouble(o_Device);
                            }
                            else
                            {
                                o_Data = this.m_MxQNUDECPUUDP.ReadDouble(o_Device);
                            }
                        }
                        break;

                    default:
                        break;

                }
            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error(ex.ToString());
                RtnCode = -1;
            }
            finally
            {
                Monitor.Exit(this);
            }

            return RtnCode;
        }

        private int _setPlcValueDouble(string o_Device, double o_Data)
        {
            int RtnCode = 0;

            if (o_Device == "" || o_Device == "NULL" || o_Device == "-1")
            {
                return RtnCode;
            }

            Monitor.Enter(this);
            try
            {
                switch ((int)this.m_ClsPlcConfig.m_EnumPlcConnectInterface)
                {
                    case (int)EnumPlcConnectInterface.ETHERNET:
                        {
                            if (this.m_ClsPlcConfig.m_stPlcEther_.IsTCP)
                            {
                                this.m_MxQJ71E71TCP.WriteDouble(o_Device, o_Data);
                            }
                            else
                            {
                                this.m_MxQJ71E71UDP.WriteDouble(o_Device, o_Data);
                            }
                        }
                        break;

                    case (int)EnumPlcConnectInterface.CPU:
                        {
                            if (this.m_ClsPlcConfig.m_stPlcCpu_.IsTCP)
                            {
                                this.m_MxQNUDECPUTCP.WriteDouble(o_Device, o_Data);
                            }
                            else
                            {
                                this.m_MxQNUDECPUUDP.WriteDouble(o_Device, o_Data);
                            }
                        }
                        break;

                    default:
                        break;

                }
            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error(ex.ToString());
                RtnCode = -1;
            }
            finally
            {
                Monitor.Exit(this);
            }

            return RtnCode;
        }

        private int _getPlcValueBlock(string o_Device, int o_Size, ref ushort[] o_Data)
        {
            int RtnCode = 0;

            if (o_Device == "" || o_Device == "NULL" || o_Device == "-1")
            {
                return RtnCode;
            }

            Monitor.Enter(this);
            try
            {
                switch ((int)this.m_ClsPlcConfig.m_EnumPlcConnectInterface)
                {
                    case (int)EnumPlcConnectInterface.ETHERNET:
                        {
                            if (this.m_ClsPlcConfig.m_stPlcEther_.IsTCP)
                            {
                                this.m_MxQJ71E71TCP.ReadDeviceBlock(o_Device, o_Size, ref o_Data);
                            }
                            else
                            {
                                this.m_MxQJ71E71UDP.ReadDeviceBlock(o_Device, o_Size, ref o_Data);
                            }
                        }
                        break;

                    case (int)EnumPlcConnectInterface.CPU:
                        {
                            if (this.m_ClsPlcConfig.m_stPlcCpu_.IsTCP)
                            {
                                this.m_MxQNUDECPUTCP.ReadDeviceBlock(o_Device, o_Size, ref o_Data);
                            }
                            else
                            {
                                this.m_MxQNUDECPUUDP.ReadDeviceBlock(o_Device, o_Size, ref o_Data);
                            }
                        }
                        break;

                    default:
                        break;

                }
            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error(ex.ToString());
                RtnCode = -1;
            }
            finally
            {
                Monitor.Exit(this);
            }

            return RtnCode;
        }
       
        private int _setPlcValueBlock(string o_Device, int o_Size, ushort[] o_Data)
        {
            int RtnCode = 0;

            if (o_Device == "" || o_Device == "NULL" || o_Device == "-1")
            {
                return RtnCode;
            }

            Monitor.Enter(this);
            try
            {
                switch ((int)this.m_ClsPlcConfig.m_EnumPlcConnectInterface)
                {
                    case (int)EnumPlcConnectInterface.ETHERNET:
                        {
                            if (this.m_ClsPlcConfig.m_stPlcEther_.IsTCP)
                            {
                                this.m_MxQJ71E71TCP.WriteDeviceBlock(o_Device, o_Size, o_Data);
                            }
                            else
                            {
                                this.m_MxQJ71E71UDP.WriteDeviceBlock(o_Device, o_Size, o_Data);
                            }
                        }
                        break;

                    case (int)EnumPlcConnectInterface.CPU:
                        {
                            if (this.m_ClsPlcConfig.m_stPlcCpu_.IsTCP)
                            {
                                this.m_MxQNUDECPUTCP.WriteDeviceBlock(o_Device, o_Size, o_Data);
                            }
                            else
                            {
                                this.m_MxQNUDECPUUDP.WriteDeviceBlock(o_Device, o_Size, o_Data);
                            }
                        }
                        break;

                    default:
                        break;

                }
            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error(ex.ToString());
                RtnCode = -1;
            }
            finally
            {
                Monitor.Exit(this);
            }

            return RtnCode;
        }

        private int _getPlcValueASCII(string o_Device, int o_Size, bool o_isLittleEnd, ref string data)
        {
            int RtnCode = 0;

            if (o_Device == "" || o_Device == "NULL" || o_Device == "-1")
            {
                return RtnCode;
            }

            Monitor.Enter(this);
            try
            {
                switch ((int)this.m_ClsPlcConfig.m_EnumPlcConnectInterface)
                {
                    case (int)EnumPlcConnectInterface.ETHERNET:
                        {
                            if (this.m_ClsPlcConfig.m_stPlcCpu_.IsTCP)
                            {
                                if (o_isLittleEnd)
                                {
                                    data = this.m_MxQJ71E71TCP.ReadLittleEndianText(o_Device, o_Size);
                                }
                                else
                                {
                                    data = this.m_MxQJ71E71TCP.ReadBigEndianText(o_Device, o_Size);
                                }
                            }
                            else
                            {
                                if (o_isLittleEnd)
                                {
                                    data = this.m_MxQJ71E71UDP.ReadLittleEndianText(o_Device, o_Size);
                                }
                                else
                                {
                                    data = this.m_MxQJ71E71UDP.ReadBigEndianText(o_Device, o_Size);
                                }
                            }
                        }
                        break;

                    case (int)EnumPlcConnectInterface.CPU:
                        {
                            if (this.m_ClsPlcConfig.m_stPlcCpu_.IsTCP)
                            {
                                if (o_isLittleEnd)
                                {
                                    data = this.m_MxQNUDECPUTCP.ReadLittleEndianText(o_Device, o_Size);
                                }
                                else
                                {
                                    data = this.m_MxQNUDECPUTCP.ReadBigEndianText(o_Device, o_Size);
                                }
                            }
                            else
                            {
                                if (o_isLittleEnd)
                                {
                                    data = this.m_MxQNUDECPUUDP.ReadLittleEndianText(o_Device, o_Size);
                                }
                                else
                                {
                                    data = this.m_MxQNUDECPUUDP.ReadBigEndianText(o_Device, o_Size);
                                }
                            }
                        }
                        break;

                    default:
                        break;

                }
            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error(ex.ToString());
                RtnCode = -1;
            }
            finally
            {
                Monitor.Exit(this);
            }

            return RtnCode;
        }

        private int _clearCoarseStatus(bool clearAlarm)
        {
            int ret = 0;

            // Coarse
            try
            {
                if (this.m_ClsPlcConfig.m_stCoarseDevice_.Enable)
                {
                    ret += this._setPlcValueBit(this.m_ClsPlcConfig.m_stCoarseDevice_.Ready_Set, 0);
                    ret += this._setPlcValueBit(this.m_ClsPlcConfig.m_stCoarseDevice_.MeasureFinish_Set, 0);

                    ret += this._setPlcValueDouble(this.m_ClsPlcConfig.m_stCoarseDevice_.MeasureResultX_Set, 0);
                    ret += this._setPlcValueDouble(this.m_ClsPlcConfig.m_stCoarseDevice_.MeasureResultY_Set, 0);
                    ret += this._setPlcValueDouble(this.m_ClsPlcConfig.m_stCoarseDevice_.MeasureResultTheta_Set, 0);

                    if (clearAlarm)
                    {
                        ret += this._setPlcValueBit(this.m_ClsPlcConfig.m_stCoarseDevice_.MeasureNG_Set, 0);
                    }
                }
            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error("Clear Coarse Status Fail " + ex.Message);
                ret = -1;
            }

            return ret;
        }

        private int _clearFineStatus(bool clearAlarm)
        {
            int ret = 0;

            // Fine
            try
            {
                if (this.m_ClsPlcConfig.m_stFineDevice_.Enable)
                {
                    ret += this._setPlcValueBit(this.m_ClsPlcConfig.m_stFineDevice_.Ready_Set, 0);
                    ret += this._setPlcValueBit(this.m_ClsPlcConfig.m_stFineDevice_.MeasureFinish_Set, 0);

                    ret += this._setPlcValueDouble(this.m_ClsPlcConfig.m_stFineDevice_.MeasureResultX_Set, 0);
                    ret += this._setPlcValueDouble(this.m_ClsPlcConfig.m_stFineDevice_.MeasureResultY_Set, 0);
                    ret += this._setPlcValueDouble(this.m_ClsPlcConfig.m_stFineDevice_.MeasureResultTheta_Set, 0);

                    if (clearAlarm)
                    {
                        ret += this._setPlcValueBit(this.m_ClsPlcConfig.m_stFineDevice_.MeasureNG_Set, 0);
                        ret += this._setPlcValueBit(this.m_ClsPlcConfig.m_stFineDevice_.CheckNG_Set, 0);
                        ret += this._setPlcValueBit(this.m_ClsPlcConfig.m_stFineDevice_.ReviewNG_Set, 0);
                    }
                }
            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error("Clear Fine Status Fail " + ex.Message);
                ret = -1;
            }

            return ret;
        }
        private int _clearLaminaterStatus(bool clearAlarm)
        {
            int ret = 0;

            // Coarse
            try
            {
                if (this.m_ClsPlcConfig.m_stLaminaterDevice_.Enable)
                {
                    ret += this._setPlcValueBit(this.m_ClsPlcConfig.m_stLaminaterDevice_.Ready_Set, 0);
                    ret += this._setPlcValueBit(this.m_ClsPlcConfig.m_stLaminaterDevice_.MeasureFinish_Set, 0);

                    ret += this._setPlcValueDouble(this.m_ClsPlcConfig.m_stLaminaterDevice_.MeasureResultX_Set, 0);
                    ret += this._setPlcValueDouble(this.m_ClsPlcConfig.m_stLaminaterDevice_.MeasureResultY_Set, 0);
                    ret += this._setPlcValueDouble(this.m_ClsPlcConfig.m_stLaminaterDevice_.MeasureResultTheta_Set, 0);

                    if (clearAlarm)
                    {
                        ret += this._setPlcValueBit(this.m_ClsPlcConfig.m_stLaminaterDevice_.MeasureNG_Set, 0);
                        ret += this._setPlcValueBit(this.m_ClsPlcConfig.m_stLaminaterDevice_.CheckNG_Set, 0);
                        ret += this._setPlcValueBit(this.m_ClsPlcConfig.m_stLaminaterDevice_.ReviewNG_Set, 0);
                    }
                }
            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error("Clear Laminater Status Fail " + ex.Message);
                ret = -1;
            }

            return ret;
        }
        private void _threadToSetHeartBeat()
        {
            try
            {
                ushort beatValue = 1;

                while (this.m_StartCoarseCapture || 
                    this.m_StartFineCapture || 
                    this.m_StartLaminaterCapture)
                {
                    int RtnCode = 0;
                    RtnCode = _setPlcValueBit(this.m_ClsPlcConfig.m_HeartBeatDevice, beatValue);

                    if (RtnCode != 0)
                    {
                        this.m_InfoManager.Error("Set heart beat fail");
                    }
                    beatValue = (ushort)(1 - beatValue);

                    Thread.Sleep(2000);
                }
            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error(ex.ToString());
            }

        }

        private void _threadToCheckCoarseReadyRequest()
        {
            ushort data = 0;
            ushort[] dataBlock = new ushort[1] { 0 };

            int pre_state = 0;

            while (this.m_StartCoarseCapture)
            {
                try
                {

                    // Get ReadyRequest
                    int RtnCode = this._getPlcValueBit(
                        this.m_ClsPlcConfig.m_stCoarseDevice_.ReadyRequest_Get,
                        ref data);

                    // Positive trigger
                    int now_state = (data == 1) ? 1 : 0;
                    bool checkFlag = (now_state - pre_state > 0) ? true : false;
                    pre_state = now_state;

                    if (checkFlag)
                    {
                        // the flag on (0->1)
                        this.funcChangeCurrentStatus("[Coarse] Get Ready Request");

                        // Set Ready
                        RtnCode = this._setPlcValueBit(
                            this.m_ClsPlcConfig.m_stCoarseDevice_.Ready_Set, 1);

                        this.funcChangeCurrentStatus("[Coarse] Set Ready");
                    }

                }
                catch (Exception ex)
                {
                    this.m_InfoManager.Error("[Coarse] ReadyRequest : " + ex.Message);
                }

                //
                Thread.Sleep(this.m_ClsPlcConfig.m_stCoarseDevice_.ScanInterval);
            }

        }

        private void _threadToCheckCoarseMeasureRequest()
        {
            ushort data = 0;
            ushort[] dataBlock = new ushort[1] { 0 };
            string dataFrameId = "";
            string dataPanelId = "";

            int pre_state = 0;

            while (this.m_StartCoarseCapture)
            {
                try
                {

                    // Get Measure Request
                    data = 0;
                    int RtnCode = this._getPlcValueBit(
                        this.m_ClsPlcConfig.m_stCoarseDevice_.MeasureRequest_Get,
                        ref data);

                    // Positive trigger
                    int now_state = (data == 1) ? 1 : 0;
                    bool checkFlag = (now_state - pre_state > 0) ? true : false;
                    pre_state = now_state;

                    if (checkFlag)
                    {
                        // the flag on (0->1)

                        // Get Posistion Information
                        RtnCode = this._getPlcValueBlock(this.m_ClsPlcConfig.m_stCoarseDevice_.PositionInfo_Get, 1, ref dataBlock);
                        this.m_InfoManager.General("Receive Position : " + dataBlock[0]);
                        this.funcChangeCurrentStatus("[Coarse] Get Measure Request " + dataBlock[0]);

                        // Get Frame ID
                        RtnCode = this._getPlcValueASCII(
                            this.m_ClsPlcConfig.m_FrameID,
                            this.m_ClsPlcConfig.m_FrameIdLength,
                            this.m_ClsPlcConfig.m_FrameIdLittleEnd,
                            ref dataFrameId);

                        // Get Glass Panel ID
                        RtnCode = this._getPlcValueASCII(
                            this.m_ClsPlcConfig.m_GlassPanelID,
                            this.m_ClsPlcConfig.m_GlassPanelIdLength,
                            this.m_ClsPlcConfig.m_GlassPanelIdLittleEnd,
                            ref dataPanelId);

                        try
                        {
                            dataFrameId = dataFrameId.Trim();
                            dataPanelId = dataPanelId.Trim();
                        }
                        catch (Exception ex) {
                            this.m_InfoManager.Error(ex.ToString());
                        }

                        // 
                        string ToDaMsg = "COARSE";

                        bool isPositionValid = true;
                        if (dataBlock[0] != 1 &&
                            dataBlock[0] != 2 &&
                            dataBlock[0] != 6)
                        {
                            isPositionValid = false;
                        }

                        if (!isPositionValid)
                        {
                            this.m_InfoManager.Error("[Coarse] Get unknown position : " + dataBlock[0]);
                        }

                        // Send to DA
                        double tempX = 0, tempY = 0, tempTheta = 0;
                        if (this.funcSendCoarseMsgToDA(ToDaMsg, dataBlock[0], dataFrameId, dataPanelId, ref tempX, ref tempY, ref tempTheta))
                        {
                            if (tempX !=0 || tempY != 0 || tempTheta != 0 )
                            {
                                RtnCode = this._setPlcValueDouble(this.m_ClsPlcConfig.m_stCoarseDevice_.MeasureResultX_Set, tempX);
                                RtnCode = this._setPlcValueDouble(this.m_ClsPlcConfig.m_stCoarseDevice_.MeasureResultY_Set, tempY);
                                RtnCode = this._setPlcValueDouble(this.m_ClsPlcConfig.m_stCoarseDevice_.MeasureResultTheta_Set, tempTheta);
                                pre_state = 0;
                                this.m_InfoManager.General("[Coarse] MeasureResult Set");
                            }
                        }
                        else
                        {
                            if (dataBlock[0] == 1 ||
                                dataBlock[0] == 6)
                            {
                                // Set Measure NG
                                RtnCode = this._setPlcValueBit(this.m_ClsPlcConfig.m_stCoarseDevice_.MeasureNG_Set, 1);
                                pre_state = 0;
                                this.m_InfoManager.General("[Coarse] MeasureNG_Set");
                            }
                            else  {
                                // Set Measure NG
                                RtnCode = this._setPlcValueBit(this.m_ClsPlcConfig.m_stCoarseDevice_.MeasureNG1_Set, 1);
                                pre_state = 0;
                                this.m_InfoManager.General("[Coarse] MeasureNG1_Set");
                            }
                        }
                        RtnCode = this._setPlcValueBit(this.m_ClsPlcConfig.m_stCoarseDevice_.MeasureFinish_Set, 1);

                    }

                }
                catch (Exception ex)
                {
                    this.m_InfoManager.Error("[Coarse] MeasureRequest : " + ex.Message);
                }

                //
                Thread.Sleep(this.m_ClsPlcConfig.m_stCoarseDevice_.ScanInterval);
            }

        }

        private void _threadToCheckFineReadyRequest()
        {
            ushort data = 0;
            ushort[] dataBlock = new ushort[1] { 0 };

            int pre_state = 0;

            while (this.m_StartFineCapture)
            {
                try
                {

                    // Get ReadyRequest
                    int RtnCode = this._getPlcValueBit(
                        this.m_ClsPlcConfig.m_stFineDevice_.ReadyRequest_Get,
                        ref data);

                    // Positive trigger
                    int now_state = (data == 1) ? 1 : 0;
                    bool checkFlag = (now_state - pre_state > 0) ? true : false;
                    pre_state = now_state;

                    if (checkFlag)
                    {
                        // the flag on (0->1)
                        this.funcChangeCurrentStatus("[Fine] Get Ready Request");

                        // Set Ready
                        RtnCode = this._setPlcValueBit(
                            this.m_ClsPlcConfig.m_stFineDevice_.Ready_Set, 1);

                        this.funcChangeCurrentStatus("[Fine] Set Ready");
                    }

                }
                catch (Exception ex)
                {
                    this.m_InfoManager.Error("[Fine] ReadyRequest : " + ex.Message);
                }

                //
                Thread.Sleep(this.m_ClsPlcConfig.m_stFineDevice_.ScanInterval);
            }

        }

        private void _threadToCheckFineMeasureRequest()
        {
            ushort data = 0;
            ushort[] dataBlock = new ushort[1] { 0 };
            string dataFrameId = "";
            string dataPanelId = "";

            int pre_state = 0;

            System.Diagnostics.Stopwatch a_stopwatch = new System.Diagnostics.Stopwatch();
            a_stopwatch.Start();

            while (this.m_StartFineCapture)
            {
                try
                {
                    // Get Measure Request
                    data = 0;
                    int RtnCode = this._getPlcValueBit(
                        this.m_ClsPlcConfig.m_stFineDevice_.MeasureRequest_Get,
                        ref data);

                    // Positive trigger
                    int now_state = (data == 1) ? 1 : 0;
                    bool checkFlag = (now_state - pre_state > 0) ? true : false;
                    pre_state = now_state;
                 
                    //if (a_stopwatch.ElapsedMilliseconds > 500)
                    //{
                    //    this.m_InfoManager.HighLight("data : " + data);
                    //    a_stopwatch.Restart();
                    //}

                    if (checkFlag)
                    {
                        // the flag on (0->1)

                        // Get Posistion Information
                        RtnCode = this._getPlcValueBlock(this.m_ClsPlcConfig.m_stFineDevice_.PositionInfo_Get, 1, ref dataBlock);
                        this.m_InfoManager.General("[Fine] Receive Position : " + dataBlock[0]);
                        this.funcChangeCurrentStatus("[Fine] Get Measure Request " + dataBlock[0]);

                        // Get Frame ID
                        RtnCode = this._getPlcValueASCII(
                            this.m_ClsPlcConfig.m_FrameID,
                            this.m_ClsPlcConfig.m_FrameIdLength,
                            this.m_ClsPlcConfig.m_FrameIdLittleEnd,
                            ref dataFrameId);

                        // Get Glass Panel ID
                        RtnCode = this._getPlcValueASCII(
                            this.m_ClsPlcConfig.m_GlassPanelID,
                            this.m_ClsPlcConfig.m_GlassPanelIdLength,
                            this.m_ClsPlcConfig.m_GlassPanelIdLittleEnd,
                            ref dataPanelId);

                        try
                        {
                            dataFrameId = dataFrameId.Trim();
                            dataPanelId = dataPanelId.Trim();
                        }
                        catch (Exception ex)
                        {
                            this.m_InfoManager.Error(ex.ToString());
                        }

                        // check if check NG. (FINE3)
                        bool isCheckNGMsg = false;

                        bool isReviewNGMsg = false;
                        
                        // 
                        string ToDaMsg = "FINE";

                        bool isPositionValid = true;
                        if (dataBlock[0] != 11 && dataBlock[0] != 12 && dataBlock[0] != 13 && dataBlock[0] != 14 &&
                            dataBlock[0] != 21 && dataBlock[0] != 22 && dataBlock[0] != 23 && dataBlock[0] != 24 &&
                            dataBlock[0] != 51 && dataBlock[0] != 52 && dataBlock[0] != 53 && dataBlock[0] != 54 &&
                            dataBlock[0] != 61 && dataBlock[0] != 62 && dataBlock[0] != 63 && dataBlock[0] != 64 &&
                            dataBlock[0] != 111 && dataBlock[0] != 112 && dataBlock[0] != 113 && dataBlock[0] != 114 &&
                            dataBlock[0] != 121 && dataBlock[0] != 122 && dataBlock[0] != 123 && dataBlock[0] != 124 &&
                            dataBlock[0] != 211 && dataBlock[0] != 212 && dataBlock[0] != 213 && dataBlock[0] != 214 &&
                            dataBlock[0] != 221 && dataBlock[0] != 222 && dataBlock[0] != 223 && dataBlock[0] != 224)
                        {
                            isPositionValid = false;
                        }
                        else if (dataBlock[0] == 111 || dataBlock[0] == 112 || dataBlock[0] == 113 || dataBlock[0] == 114 ||
                             dataBlock[0] == 121 || dataBlock[0] == 122 || dataBlock[0] == 123 || dataBlock[0] == 124)
                        {
                            isCheckNGMsg = true;
                        }
                        else if (dataBlock[0] == 211 || dataBlock[0] == 212 || dataBlock[0] == 213 || dataBlock[0] == 214 ||
                           dataBlock[0] == 221 || dataBlock[0] == 222 || dataBlock[0] == 223 || dataBlock[0] == 224)
                        {
                            isReviewNGMsg = true;
                        }


                        if (!isPositionValid)
                        {
                            this.m_InfoManager.Error("[Fine] Get unknown position : " + dataBlock[0]);
                        }

                        // Send to DA
                        double tempX = 0, tempY = 0, tempTheta = 0;
                        if (this.funcSendFineMsgToDA(ToDaMsg, dataBlock[0], dataFrameId, dataPanelId, ref tempX, ref tempY, ref tempTheta))
                        {
                            if (tempX != 0 || tempY != 0 || tempTheta != 0)
                            {
                                RtnCode = this._setPlcValueDouble(this.m_ClsPlcConfig.m_stFineDevice_.MeasureResultX_Set, tempX);
                                RtnCode = this._setPlcValueDouble(this.m_ClsPlcConfig.m_stFineDevice_.MeasureResultY_Set, tempY);
                                RtnCode = this._setPlcValueDouble(this.m_ClsPlcConfig.m_stFineDevice_.MeasureResultTheta_Set, tempTheta);
                                pre_state = 0;
                                this.m_InfoManager.General("[Fine] MeasureResult Set");
                            }

                        }
                        else
                        {
                            if (isCheckNGMsg)
                            {
                                // Set Check NG
                                RtnCode = this._setPlcValueBit(this.m_ClsPlcConfig.m_stFineDevice_.CheckNG_Set, 1);
                                pre_state = 0;
                                this.m_InfoManager.General("[Fine] CheckNG_Set : " + this.m_ClsPlcConfig.m_stFineDevice_.CheckNG_Set);
                            }
                                // Set Review NG
                            else if (isReviewNGMsg)
                            {
                                RtnCode = this._setPlcValueBit(this.m_ClsPlcConfig.m_stFineDevice_.ReviewNG_Set, 1);
                                pre_state = 0;
                                this.m_InfoManager.General("[Fine] CheckNG_Set : " + this.m_ClsPlcConfig.m_stFineDevice_.ReviewNG_Set);
                            }
                            else
                            {
                                // Set Measure NG
                                RtnCode = this._setPlcValueBit(this.m_ClsPlcConfig.m_stFineDevice_.MeasureNG_Set, 1);
                                pre_state = 0;
                                this.m_InfoManager.General("[Fine] MeasureNG_Set : " + this.m_ClsPlcConfig.m_stFineDevice_.MeasureNG_Set);
                            }
                      
                        }
                        RtnCode = this._setPlcValueBit(this.m_ClsPlcConfig.m_stFineDevice_.MeasureFinish_Set, 1);
                        this.m_InfoManager.General("[Fine] MeasureFinish_Set : " + this.m_ClsPlcConfig.m_stFineDevice_.MeasureFinish_Set);
                    }
                }
                catch (Exception ex)
                {
                    this.m_InfoManager.Error("[Fine] MeasureRequest : " + ex.Message);
                }

                //
                Thread.Sleep(this.m_ClsPlcConfig.m_stFineDevice_.ScanInterval);
            }

        }

        private void _threadToCheckLaminaterReadyRequest()
        {
            ushort data = 0;
            ushort[] dataBlock = new ushort[1] { 0 };

            int pre_state = 0;

            while (this.m_StartLaminaterCapture)
            {
                try
                {

                    // Get ReadyRequest
                    int RtnCode = this._getPlcValueBit(
                        this.m_ClsPlcConfig.m_stLaminaterDevice_.ReadyRequest_Get,
                        ref data);

                    // Positive trigger
                    int now_state = (data == 1) ? 1 : 0;
                    bool checkFlag = (now_state - pre_state > 0) ? true : false;
                    pre_state = now_state;

                    if (checkFlag)
                    {
                        // the flag on (0->1)
                        this.funcChangeCurrentStatus("[Laminater] Get Ready Request");

                        // Set Ready
                        RtnCode = this._setPlcValueBit(
                            this.m_ClsPlcConfig.m_stLaminaterDevice_.Ready_Set, 1);

                        this.funcChangeCurrentStatus("[Laminater] Set Ready");
                    }

                }
                catch (Exception ex)
                {
                    this.m_InfoManager.Error("[Laminater] ReadyRequest : " + ex.Message);
                }

                //
                Thread.Sleep(this.m_ClsPlcConfig.m_stLaminaterDevice_.ScanInterval);
            }

        }
        private void _threadToCheckLaminaterMeasureRequest()
        {
            ushort data = 0;
            ushort[] dataBlock = new ushort[1] { 0 };
            string dataFrameId = "";
            string dataPanelId = "";

            int pre_state = 0;

            System.Diagnostics.Stopwatch a_stopwatch = new System.Diagnostics.Stopwatch();
            a_stopwatch.Start();

            while (this.m_StartLaminaterCapture)
            {
                try
                {
                    // Get Measure Request
                    data = 0;
                    int RtnCode = this._getPlcValueBit(
                        this.m_ClsPlcConfig.m_stLaminaterDevice_.MeasureRequest_Get,
                        ref data);

                    // Positive trigger
                    int now_state = (data == 1) ? 1 : 0;
                    bool checkFlag = (now_state - pre_state > 0) ? true : false;
                    pre_state = now_state;

                    //if (a_stopwatch.ElapsedMilliseconds > 500)
                    //{
                    //    this.m_InfoManager.HighLight("data : " + data);
                    //    a_stopwatch.Restart();
                    //}

                    if (checkFlag)
                    {
                        // the flag on (0->1)

                        // Get Posistion Information
                        RtnCode = this._getPlcValueBlock(this.m_ClsPlcConfig.m_stLaminaterDevice_.PositionInfo_Get, 1, ref dataBlock);
                        this.m_InfoManager.General("[Laminater] Receive Position : " + dataBlock[0]);
                        this.funcChangeCurrentStatus("[Laminater] Get Measure Request " + dataBlock[0]);

                        // Get Frame ID
                        RtnCode = this._getPlcValueASCII(
                            this.m_ClsPlcConfig.m_FrameID,
                            this.m_ClsPlcConfig.m_FrameIdLength,
                            this.m_ClsPlcConfig.m_FrameIdLittleEnd,
                            ref dataFrameId);

                        // Get Glass Panel ID
                        RtnCode = this._getPlcValueASCII(
                            this.m_ClsPlcConfig.m_GlassPanelID,
                            this.m_ClsPlcConfig.m_GlassPanelIdLength,
                            this.m_ClsPlcConfig.m_GlassPanelIdLittleEnd,
                            ref dataPanelId);

                        try
                        {
                            dataFrameId = dataFrameId.Trim();
                            dataPanelId = dataPanelId.Trim();
                        }
                        catch (Exception ex)
                        {
                            this.m_InfoManager.Error(ex.ToString());
                        }

                        // check if check NG. (FINE3)
                        bool isCheckNGMsg = false;

                        bool isReviewNGMsg = false;

                        // 
                        string ToDaMsg = "Laminater";

                        bool isPositionValid = true;
                        if (dataBlock[0] != 1 && dataBlock[0] != 2 &&
                            dataBlock[0] != 11 && dataBlock[0] != 12 && dataBlock[0] != 13 &&
                            dataBlock[0] != 21 )
                        {
                            isPositionValid = false;
                        }
                        else if (dataBlock[0] == 11 || dataBlock[0] == 12 || dataBlock[0] == 13 )
                        {
                            isCheckNGMsg = true;
                        }
                        else if (dataBlock[0] == 21 )
                        {
                            isReviewNGMsg = true;
                        }


                        if (!isPositionValid)
                        {
                            this.m_InfoManager.Error("[Laminater] Get unknown position : " + dataBlock[0]);
                        }

                        // Send to DA
                        double tempX = 0, tempY = 0, tempTheta = 0;
                        if (this.funcSendLaminaterMsgToDA(ToDaMsg, dataBlock[0], dataFrameId, dataPanelId, ref tempX, ref tempY, ref tempTheta))
                        {
                            if (tempX != 0 || tempY != 0 || tempTheta != 0)
                            {
                                RtnCode = this._setPlcValueDouble(this.m_ClsPlcConfig.m_stLaminaterDevice_.MeasureResultX_Set, tempX);
                                RtnCode = this._setPlcValueDouble(this.m_ClsPlcConfig.m_stLaminaterDevice_.MeasureResultY_Set, tempY);
                                RtnCode = this._setPlcValueDouble(this.m_ClsPlcConfig.m_stLaminaterDevice_.MeasureResultTheta_Set, tempTheta);
                                pre_state = 0;
                                this.m_InfoManager.General("[Laminater] MeasureResult Set");
                            }

                        }
                        else
                        {
                            if (isCheckNGMsg)
                            {
                                // Set Check NG
                                RtnCode = this._setPlcValueBit(this.m_ClsPlcConfig.m_stLaminaterDevice_.CheckNG_Set, 1);
                                pre_state = 0;
                                this.m_InfoManager.General("[Laminater] CheckNG_Set : " + this.m_ClsPlcConfig.m_stLaminaterDevice_.CheckNG_Set);
                            }
                            // Set Review NG
                            else if (isReviewNGMsg)
                            {
                                RtnCode = this._setPlcValueBit(this.m_ClsPlcConfig.m_stLaminaterDevice_.ReviewNG_Set, 1);
                                pre_state = 0;
                                this.m_InfoManager.General("[Laminater] CheckNG_Set : " + this.m_ClsPlcConfig.m_stLaminaterDevice_.ReviewNG_Set);
                            }
                            else
                            {
                                // Set Measure NG
                                RtnCode = this._setPlcValueBit(this.m_ClsPlcConfig.m_stLaminaterDevice_.MeasureNG_Set, 1);
                                pre_state = 0;
                                this.m_InfoManager.General("[Laminater] MeasureNG_Set : " + this.m_ClsPlcConfig.m_stLaminaterDevice_.MeasureNG_Set);
                            }

                        }
                        RtnCode = this._setPlcValueBit(this.m_ClsPlcConfig.m_stLaminaterDevice_.MeasureFinish_Set, 1);
                        this.m_InfoManager.General("[Laminater] MeasureFinish_Set : " + this.m_ClsPlcConfig.m_stLaminaterDevice_.MeasureFinish_Set);
                    }
                }
                catch (Exception ex)
                {
                    this.m_InfoManager.Error("[Laminater] MeasureRequest : " + ex.Message);
                }

                //
                Thread.Sleep(this.m_ClsPlcConfig.m_stLaminaterDevice_.ScanInterval);
            }

        }



        public ClsPlcControl(ClsPlcConfig o_ClsPlcConfig, CommonBase.Logger.InfoManager o_InfoManager)
        {
            this.m_ClsPlcConfig = o_ClsPlcConfig;

            this.m_InfoManager = o_InfoManager;

            switch ((int)this.m_ClsPlcConfig.m_EnumPlcConnectInterface)
            {
                case (int)EnumPlcConnectInterface.ETHERNET:
                    {
                        if (this.m_ClsPlcConfig.m_stPlcEther_.IsTCP)
                        {
                            this.m_MxQJ71E71TCP = new Mitsubishi.Ether.MxQJ71E71TCP();
                        }
                        else
                        {
                            this.m_MxQJ71E71UDP = new Mitsubishi.Ether.MxQJ71E71UDP();
                        }
                    }
                    break;

                
                case (int)EnumPlcConnectInterface.CPU:
                    {
                        if (this.m_ClsPlcConfig.m_stPlcCpu_.IsTCP)
                        {
                            this.m_MxQNUDECPUTCP = new Mitsubishi.Ether.MxQNUDECPUTCP();
                        }
                        else
                        {
                            this.m_MxQNUDECPUUDP = new Mitsubishi.Ether.MxQNUDECPUUDP();
                        }
                    }
                    break;

                default:
                    break;

            }
        }

        public bool Initial()
        {
            bool ret = true;

            // Initial Plc
            if (this.m_ClsPlcConfig.m_stCoarseDevice_.Enable ||
                this.m_ClsPlcConfig.m_stFineDevice_.Enable || this.m_ClsPlcConfig.m_stLaminaterDevice_.Enable)
            {

                try
                {
                    switch ((int)this.m_ClsPlcConfig.m_EnumPlcConnectInterface)
                    {
                        case (int)EnumPlcConnectInterface.ETHERNET:
                            {
                                if (this.m_ClsPlcConfig.m_stPlcEther_.IsTCP)
                                {
                                    this.m_MxQJ71E71TCP.OpenMx(
                                        this.m_ClsPlcConfig.m_stPlcEther_.PlcNetworkNo,
                                        this.m_ClsPlcConfig.m_stPlcEther_.PlcStationNo,
                                        this.m_ClsPlcConfig.m_stPlcEther_.PcStationNo,
                                        this.m_ClsPlcConfig.m_stPlcEther_.PlcIpAddress,
                                        this.m_ClsPlcConfig.m_stPlcEther_.PortNo);
                                }
                                else
                                {
                                    this.m_MxQJ71E71UDP.OpenMx(
                                        this.m_ClsPlcConfig.m_stPlcEther_.PlcNetworkNo,
                                        this.m_ClsPlcConfig.m_stPlcEther_.PlcStationNo,
                                        this.m_ClsPlcConfig.m_stPlcEther_.PcStationNo,
                                        this.m_ClsPlcConfig.m_stPlcEther_.PlcIpAddress,
                                        this.m_ClsPlcConfig.m_stPlcEther_.PortNo);
                                }
                            }
                            break;

                        case (int)EnumPlcConnectInterface.CPU:
                            {
                                if (this.m_ClsPlcConfig.m_stPlcCpu_.IsTCP)
                                {
                                    this.m_MxQNUDECPUTCP.OpenMx(
                                        this.m_ClsPlcConfig.m_stPlcCpu_.PlcIpAddress);
                                }
                                else
                                {
                                    this.m_MxQNUDECPUUDP.OpenMx(
                                        this.m_ClsPlcConfig.m_stPlcCpu_.PlcIpAddress,
                                        false);
                                }
                            }
                            break;

                        default:
                            break;
                    }
                }
                catch (Exception ex)
                {
                    this.m_InfoManager.Error("[PLC] Initial Fail " + ex.Message);

                    ret = false;
                }
            }
            return ret;
        }

        //
        public void StartDetect()
        {

            // Clear PC set Plc Device to 0
            if (this._clearCoarseStatus(true) != 0)
            {
                this.m_InfoManager.Debug("[Coarse] Clear PC set Plc Device to 0 Fail");
            }

            if (this._clearFineStatus(true) != 0)
            {
                this.m_InfoManager.Debug("[Fine] Clear PC set Plc Device to 0 Fail");
            }

            if (this._clearLaminaterStatus(true) != 0)
            {
                this.m_InfoManager.Debug("[Laminater] Clear PC set Plc Device to 0 Fail");
            }

            // Coarse
            if (this.m_ClsPlcConfig.m_stCoarseDevice_.Enable)
            {
                this.m_StartCoarseCapture = true;

                //
                Thread checkCoarseReadyRequest = new Thread(new ThreadStart(_threadToCheckCoarseReadyRequest));
                checkCoarseReadyRequest.Name = "checkCoarseReadyRequest";
                checkCoarseReadyRequest.Start();

                //
                Thread checkCoarseMeasureRequest = new Thread(new ThreadStart(_threadToCheckCoarseMeasureRequest));
                checkCoarseMeasureRequest.Name = "checkCoarseMeasureRequest";
                checkCoarseMeasureRequest.Start();

                this.m_InfoManager.General("[Coarse] Start Check Device");
            }

            // Fine
            if (this.m_ClsPlcConfig.m_stFineDevice_.Enable)
            {
                this.m_StartFineCapture = true;

                //
                Thread checkFineReadyRequest = new Thread(new ThreadStart(_threadToCheckFineReadyRequest));
                checkFineReadyRequest.Name = "checkFineReadyRequest";
                checkFineReadyRequest.Start();

                //
                Thread checkFineMeasureRequest = new Thread(new ThreadStart(_threadToCheckFineMeasureRequest));
                checkFineMeasureRequest.Name = "checkFineMeasureRequest";
                checkFineMeasureRequest.Start();

                this.m_InfoManager.General("[Fine] Start Check Device");
            }
            // Laminater
            if (this.m_ClsPlcConfig.m_stLaminaterDevice_.Enable)
            {
                this.m_StartLaminaterCapture = true;

                //
                Thread checkLaminaterReadyRequest = new Thread(new ThreadStart(_threadToCheckLaminaterReadyRequest));
                checkLaminaterReadyRequest.Name = "checkLaminaterReadyRequest";
                checkLaminaterReadyRequest.Start();

                //
                Thread checkLaminaterMeasureRequest = new Thread(new ThreadStart(_threadToCheckLaminaterMeasureRequest));
                checkLaminaterMeasureRequest.Name = "checkLaminaterMeasureRequest";
                checkLaminaterMeasureRequest.Start();

                this.m_InfoManager.General("[Laminater] Start Check Device");
            }

            // Heart beat
            Thread HeartBeatThread = new Thread(new ThreadStart(_threadToSetHeartBeat));
            HeartBeatThread.Name = "HeartBeat";
            HeartBeatThread.Start();
            this.m_InfoManager.General("[All] Start Heart Beat");

        }

        public bool StopDetect()
        {
            this.m_StartCoarseCapture = false;
            this.m_StartFineCapture = false;
            this.m_StartLaminaterCapture = false;

            Thread.Sleep(500);

            // Close
            bool ret = true;
            try
            {
                switch ((int)this.m_ClsPlcConfig.m_EnumPlcConnectInterface)
                {
                    case (int)EnumPlcConnectInterface.ETHERNET:
                        {
                            if (this.m_ClsPlcConfig.m_stPlcEther_.IsTCP)
                            {
                                this.m_MxQJ71E71TCP.CloseMx();
                            }
                            else
                            {
                                this.m_MxQJ71E71UDP.CloseMx();
                            }
                        }
                        break;

                    case (int)EnumPlcConnectInterface.CPU:
                        {
                            if (this.m_ClsPlcConfig.m_stPlcCpu_.IsTCP)
                            {
                                this.m_MxQNUDECPUTCP.CloseMx();
                            }
                            else
                            {
                                this.m_MxQNUDECPUUDP.CloseMx();
                            }
                        }
                        break;

                    default:
                        break;

                }
            }
            catch (Exception ex) {
                this.m_InfoManager.Error(ex.ToString());
                ret = false;
            }

            return ret;       
        }

        public void CheckConfig()
        {
            this.m_InfoManager.General("Enable : " + this.m_ClsPlcConfig.m_stCoarseDevice_.Enable);

            this.m_InfoManager.General("ReadyRequest_Get : " + this.m_ClsPlcConfig.m_stCoarseDevice_.ReadyRequest_Get);
            this.m_InfoManager.General("Ready_Set : " + this.m_ClsPlcConfig.m_stCoarseDevice_.Ready_Set);
            this.m_InfoManager.General("MeasureRequest_Get : " + this.m_ClsPlcConfig.m_stCoarseDevice_.MeasureRequest_Get);
            this.m_InfoManager.General("PositionInfo_Get : " + this.m_ClsPlcConfig.m_stCoarseDevice_.PositionInfo_Get);

            this.m_InfoManager.General("MeasureFinish_Set : " + this.m_ClsPlcConfig.m_stCoarseDevice_.MeasureFinish_Set);
            this.m_InfoManager.General("MeasureResultX_Set : " + this.m_ClsPlcConfig.m_stCoarseDevice_.MeasureResultX_Set);
            this.m_InfoManager.General("MeasureResultY_Set : " + this.m_ClsPlcConfig.m_stCoarseDevice_.MeasureResultY_Set);
            this.m_InfoManager.General("MeasureResultTheta_Set : " + this.m_ClsPlcConfig.m_stCoarseDevice_.MeasureResultTheta_Set);

            this.m_InfoManager.General("ReceiveMeasure_Get : " + this.m_ClsPlcConfig.m_stCoarseDevice_.ReceiveMeasure_Get);

            this.m_InfoManager.General("ScanInterval : " + this.m_ClsPlcConfig.m_stCoarseDevice_.ScanInterval);
        }

        public void CheckValue()
        {
            int RtnCode = 0;
            ushort[] dataBlock = new ushort[1] { 0 };

            dataBlock[0] = 0;
            RtnCode = this._getPlcValueBlock(this.m_ClsPlcConfig.m_stCoarseDevice_.PositionInfo_Get, 1, ref dataBlock);
            this.m_InfoManager.General("[Coarse] Position : " + dataBlock[0]);

            dataBlock[0] = 0;
            RtnCode = this._getPlcValueBlock(this.m_ClsPlcConfig.m_stFineDevice_.PositionInfo_Get, 1, ref dataBlock);
            this.m_InfoManager.General("[Fine] Position : " + dataBlock[0]);

            dataBlock[0] = 0;
            RtnCode = this._getPlcValueBlock(this.m_ClsPlcConfig.m_stLaminaterDevice_.PositionInfo_Get, 1, ref dataBlock);
            this.m_InfoManager.General("[Laminater] Position : " + dataBlock[0]);
        }


        //
        public int GetPlcValueBit(string o_Device, ref ushort o_Data)
        {
            return this._getPlcValueBit(o_Device, ref o_Data);
        }

        public int SetPlcValueBit(string o_Device, ref ushort o_Data)
        {
            return this._setPlcValueBit(o_Device, o_Data);
        }

        public int GetPlcValueDouble(string o_Device, ref double o_Data)
        {
            return this._getPlcValueDouble(o_Device, ref o_Data);
        }

        public int SetPlcValueDouble(string o_Device, ref double o_Data)
        {
            return this._setPlcValueDouble(o_Device, o_Data);
        }

        public int GetPlcValueBlock(string o_Device, int o_Size, ref ushort[] o_Data)
        {
            return this._getPlcValueBlock(o_Device, o_Size, ref o_Data);
        }

        public int SetPlcValueBlock(string o_Device, int o_Size, ref ushort[] o_Data)
        {
            return this._setPlcValueBlock(o_Device, o_Size, o_Data);
        }

        public void ResetToInitial()
        {
            try
            {
                //
                this._clearCoarseStatus(true);
                this._clearFineStatus(true);
                this._clearLaminaterStatus(true);

                //
                this.m_InfoManager.HighLight("Click reset to initial");

            }
            catch (Exception ex)
            {
                this.m_InfoManager.Error(ex.ToString());
            }

        }

    }
}
