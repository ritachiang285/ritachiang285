namespace MonitorFolderActivity
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstFolders = new System.Windows.Forms.ListBox();
            this.lstResultLog = new System.Windows.Forms.ListBox();
            this.chkMonitorUpdated = new System.Windows.Forms.CheckBox();
            this.chkMonitorDeleted = new System.Windows.Forms.CheckBox();
            this.chkMonitorCreated = new System.Windows.Forms.CheckBox();
            this.btnRun = new System.Windows.Forms.Button();
            this.txtMonitorFileExpression = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lstFolders
            // 
            this.lstFolders.FormattingEnabled = true;
            this.lstFolders.Items.AddRange(new object[] {
            "D:\\Share",
            "D:\\Share2"});
            this.lstFolders.Location = new System.Drawing.Point(12, 12);
            this.lstFolders.Name = "lstFolders";
            this.lstFolders.Size = new System.Drawing.Size(299, 95);
            this.lstFolders.TabIndex = 0;
            // 
            // lstResultLog
            // 
            this.lstResultLog.FormattingEnabled = true;
            this.lstResultLog.Location = new System.Drawing.Point(12, 113);
            this.lstResultLog.Name = "lstResultLog";
            this.lstResultLog.Size = new System.Drawing.Size(299, 251);
            this.lstResultLog.TabIndex = 8;
            // 
            // chkMonitorUpdated
            // 
            this.chkMonitorUpdated.AutoSize = true;
            this.chkMonitorUpdated.Checked = true;
            this.chkMonitorUpdated.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkMonitorUpdated.Location = new System.Drawing.Point(12, 370);
            this.chkMonitorUpdated.Name = "chkMonitorUpdated";
            this.chkMonitorUpdated.Size = new System.Drawing.Size(105, 17);
            this.chkMonitorUpdated.TabIndex = 9;
            this.chkMonitorUpdated.Text = "Monitor Updated";
            this.chkMonitorUpdated.UseVisualStyleBackColor = true;
            // 
            // chkMonitorDeleted
            // 
            this.chkMonitorDeleted.AutoSize = true;
            this.chkMonitorDeleted.Checked = true;
            this.chkMonitorDeleted.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkMonitorDeleted.Location = new System.Drawing.Point(12, 394);
            this.chkMonitorDeleted.Name = "chkMonitorDeleted";
            this.chkMonitorDeleted.Size = new System.Drawing.Size(101, 17);
            this.chkMonitorDeleted.TabIndex = 10;
            this.chkMonitorDeleted.Text = "Monitor Deleted";
            this.chkMonitorDeleted.UseVisualStyleBackColor = true;
            // 
            // chkMonitorCreated
            // 
            this.chkMonitorCreated.AutoSize = true;
            this.chkMonitorCreated.Checked = true;
            this.chkMonitorCreated.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkMonitorCreated.Location = new System.Drawing.Point(12, 417);
            this.chkMonitorCreated.Name = "chkMonitorCreated";
            this.chkMonitorCreated.Size = new System.Drawing.Size(101, 17);
            this.chkMonitorCreated.TabIndex = 11;
            this.chkMonitorCreated.Text = "Monitor Created";
            this.chkMonitorCreated.UseVisualStyleBackColor = true;
            // 
            // btnRun
            // 
            this.btnRun.Location = new System.Drawing.Point(236, 411);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(75, 23);
            this.btnRun.TabIndex = 12;
            this.btnRun.Text = "Run";
            this.btnRun.UseVisualStyleBackColor = true;
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // txtMonitorFileExpression
            // 
            this.txtMonitorFileExpression.Location = new System.Drawing.Point(180, 386);
            this.txtMonitorFileExpression.Name = "txtMonitorFileExpression";
            this.txtMonitorFileExpression.Size = new System.Drawing.Size(131, 20);
            this.txtMonitorFileExpression.TabIndex = 13;
            this.txtMonitorFileExpression.Text = "*.*";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(233, 370);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "Files to Monitor";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(326, 446);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtMonitorFileExpression);
            this.Controls.Add(this.btnRun);
            this.Controls.Add(this.chkMonitorCreated);
            this.Controls.Add(this.chkMonitorDeleted);
            this.Controls.Add(this.chkMonitorUpdated);
            this.Controls.Add(this.lstResultLog);
            this.Controls.Add(this.lstFolders);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstFolders;
        private System.Windows.Forms.ListBox lstResultLog;
        private System.Windows.Forms.CheckBox chkMonitorUpdated;
        private System.Windows.Forms.CheckBox chkMonitorDeleted;
        private System.Windows.Forms.CheckBox chkMonitorCreated;
        private System.Windows.Forms.Button btnRun;
        private System.Windows.Forms.TextBox txtMonitorFileExpression;
        private System.Windows.Forms.Label label1;
    }
}

